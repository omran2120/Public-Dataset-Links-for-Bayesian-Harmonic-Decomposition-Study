# Bayesian Harmonic Residual (sigma_BH) -- code and derived results

Reproducibility materials for:
**"Bayesian harmonic decomposition for machinery fault diagnosis with uncertainty quantification"**
O. Abdallah, E. Altamimi, M. Abdallah.

The Bayesian Harmonic Residual sigma_BH is a closed-form vibration fault indicator. The
acceleration is ridge-regressed on a sinusoidal basis of FFT-detected peaks under conjugate
Normal-Inverse-Gamma priors, and the residual scale (with a credible interval) is read from the
closed-form posterior:

    sigma_BH(x) = sqrt[ (b0 + 0.5 * x^T (I - H_lambda) x) / (a0 + N/2 - 1) ],
    H_lambda    = Phi (Phi^T Phi + lambda I)^-1 Phi^T

See the manuscript for full details.

## Contents
- `code/`   -- the method and all analysis/figure scripts (Python 3, plus one MATLAB script)
  - `bayesian_harmonic_diagnostic.py` -- the sigma_BH operator (core method)
  - `run_all_datasets.py`             -- runs the operator across all datasets
  - `benchmark_all_indicators.py`     -- FDR/AUC vs RMS, kurtosis, kurtogram, infogram, SES, AR-RMS
  - `empirical_ci_analysis.py`        -- within-window and across-measurement uncertainty intervals
  - `regime_rule_analysis.py`         -- R^2-based sigma vs sigma_norm regime rule
  - `ar_baseline_analysis.py`         -- autoregressive (AR) prewhitening baseline
  - `lambda_sensitivity.py`           -- sensitivity to the ridge lambda
  - `task3_validation.py`             -- pseudo-replication, leave-one-load/bearing-out, N_f sensitivity
  - `generate_all_figures.py`, `generate_uncertainty_figure.py`, `gen_cwru_figures.py`,
    `export_cwru_mat.py`, `plot_cwru_paper.m` -- figure generation
- `results/` -- derived data (the computed numbers behind every table and figure)
  - `empirical_ci_results.{json,txt}`, `sigma_across_measurement.json` -- per-class sigma and CIs
  - `auc_balanced_accuracy.json`, `benchmark_output.txt` -- benchmark FDR/AUC tables
  - `ar_baseline_results.json`, `lambda_sensitivity.json` -- AR baseline + lambda sweep
  - `task3_features.json` -- per-window sigma, sigma_norm, R^2, kurtosis (CWRU + Paderborn)
  - `task3_results.json`  -- validation metrics (leave-one-out, file-level, N_f)
  - `cwru_results.mat`    -- per-window CWRU features used by the MATLAB figure script
- `manuscript/` -- `RESS_main.tex`, `references.bib`

## Raw datasets (public -- NOT redistributed here)
The six benchmarks are public; download from the original providers and point the scripts at them:
- CWRU:       https://engineering.case.edu/bearingdatacenter
- Paderborn:  https://mb.uni-paderborn.de/kat/forschung/datacenter/bearing-datacenter/
- UOttawa:    Mendeley Data (see manuscript reference)
- JNU:        https://github.com/ClarkGableWang/JNU-Bearing-Dataset
- MFPT:       https://www.mfpt.org/fault-data-sets/
- MCC5-THU:   Mendeley Data (see manuscript reference)

## Reproducing
1. Python 3.10+ with `numpy`, `scipy`, `matplotlib`; MATLAB for `plot_cwru_paper.m`.
2. The dataset paths at the top of the scripts are currently absolute local paths --
   edit them to point at your local copies of the public datasets above.
3. Run e.g.:
       python code/run_all_datasets.py
       python code/task3_validation.py
       python code/gen_cwru_figures.py      # then plot_cwru_paper.m in MATLAB

## Notes
- `sigma_BH` is a regularized posterior scale; for the weak prior / long windows used here it is
  numerically close to the ordinary residual standard deviation (see manuscript Section on the operator).
- License: add your preferred license (e.g., MIT) before publishing.

## Citation
To be completed on acceptance (add the published reference / BibTeX here).
