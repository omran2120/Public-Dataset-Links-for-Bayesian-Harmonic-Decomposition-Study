"""
AR-prewhitening baseline for Priority 3.

For each dataset and window:
  - Fit AR(p) model via Yule-Walker
  - Compute residual (innovation) sequence
  - Extract residual RMS and residual kurtosis as diagnostic features
  - Compute FDR on each across all 7 dataset/regime conditions

Also computes the proposed sigma family for direct comparison.

Choice of AR order: p = 100. Rationale: this is large enough to capture the
shaft and mesh harmonics for the bearing/gear sample rates used here
(12--50 kHz, shaft 25--30 Hz, period 400--2000 samples; the autocorrelation
lags up to p=100 capture the first several harmonics) while small enough
that the residual is not over-fitted on N >= 12000-sample windows. This is
within the range used by Endo & Randall [13] and the bearing literature
that follows. Sensitivity to p is reported separately.
"""

import os
import sys
import json
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
from scipy.linalg import solve_toeplitz, LinAlgError
from scipy.stats import kurtosis as sp_kurtosis
from functools import partial

print = partial(print, flush=True)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)

AR_ORDER = 100  # see file docstring


# ------------------------------------------------------------------
#  AR prewhitening via Yule-Walker
# ------------------------------------------------------------------
def ar_residual(x, p=AR_ORDER):
    """Fit AR(p) by Yule-Walker, return the prediction-error residual.

    Residual length is len(x) - p (initial transient discarded).
    """
    from scipy.signal import lfilter
    x = np.asarray(x, float)
    x = x - np.mean(x)
    N = len(x)
    if N <= p + 10:
        return None
    # Biased autocorrelation (Yule-Walker form)
    r = np.correlate(x, x, mode="full")[N - 1: N - 1 + p + 1] / N
    try:
        a = solve_toeplitz(r[:p], r[1:p + 1])
    except LinAlgError:
        return None
    # AR model: x[n] = sum_{k=1..p} a[k-1] * x[n-k] + e[n]
    # Apply FIR filter b = [1, -a[0], -a[1], ..., -a[p-1]] to x to get e.
    b = np.concatenate(([1.0], -a))
    e = lfilter(b, [1.0], x)
    # Discard the first p samples (filter transient where past values are zero)
    return e[p:]


def ar_features(x, p=AR_ORDER):
    e = ar_residual(x, p)
    if e is None or len(e) == 0:
        return None
    rms_e = float(np.sqrt(np.mean(e ** 2)))
    kurt_e = float(sp_kurtosis(e, fisher=True))
    return {"ar_rms": rms_e, "ar_kurt": kurt_e}


def fdr(h, f):
    h, f = np.asarray(h, float), np.asarray(f, float)
    s = np.var(h, ddof=0) + np.var(f, ddof=0)
    return float((np.mean(h) - np.mean(f)) ** 2 / s) if s > 1e-20 else 0.0


# ------------------------------------------------------------------
#  Dataset loaders (same as regime_rule_analysis.py)
# ------------------------------------------------------------------
all_results = {}


def analyse_window(seg, fs):
    """Compute Bayesian sigma + AR features in one go."""
    f = bhd.analyze(seg, fs)
    if f is None:
        return None
    arf = ar_features(seg)
    if arf is None:
        return None
    f.update(arf)
    return f


# CWRU
print("Loading CWRU...", end=" ")
cwru_dir = os.path.join(HERE, "..", "data", "cwru")
cwru_cat = {"97": "N", "98": "N", "99": "N", "100": "N",
            "105": "IR", "106": "IR", "107": "IR", "108": "IR",
            "169": "IR", "170": "IR", "171": "IR", "172": "IR",
            "209": "IR", "210": "IR", "211": "IR", "212": "IR",
            "118": "B", "119": "B", "120": "B", "121": "B",
            "185": "B", "186": "B", "187": "B", "188": "B",
            "222": "B", "223": "B", "224": "B", "225": "B",
            "130": "OR", "131": "OR", "132": "OR", "133": "OR",
            "197": "OR", "198": "OR", "199": "OR", "200": "OR",
            "234": "OR", "235": "OR", "236": "OR", "237": "OR"}
res = []
for fnum, cond in cwru_cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath):
        continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys:
        continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w * 12000:(w + 1) * 12000]
        if len(seg) < 12000:
            break
        f = analyse_window(seg, 12000)
        if f:
            f["condition"] = cond
            res.append(f)
all_results["CWRU"] = ("N", res)
print(f"{len(res)} windows")

# Paderborn
print("Loading Paderborn...", end=" ")
pb_dir = os.path.join(HERE, "..", "data", "paderborn")
pb_map = {"K001": "H", "K002": "H", "KA01": "OR", "KA04": "OR",
          "KI01": "IR", "KI04": "IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath):
        bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath):
        continue
    files = sorted([f for f in os.listdir(bpath)
                    if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0, 0]["Y"][0, 6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w * 16000:(w + 1) * 16000]
            if len(seg) < 16000:
                break
            f = analyse_window(seg, 16000)
            if f:
                f["condition"] = cond
                res.append(f)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)} windows")

# UOttawa
print("Loading UOttawa...", end=" ")
uo_dir = os.path.join(HERE, "..", "..", "data", "uottawa_mendeley")
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"):
            continue
        cc = fname[0]
        if cc not in "HOIBC":
            continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"):
                continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    f = analyse_window(data[:20000], 20000)
                    if f:
                        f["condition"] = cond
                        res.append(f)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)} windows")

# JNU
print("Loading JNU...", end=" ")
jnu_dir = os.path.join(HERE, "..", "data", "jnu")
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"):
            continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1:
                data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data) // 50000)):
                seg = data[w * 50000:(w + 1) * 50000]
                f = analyse_window(seg, 50000)
                if f:
                    f["condition"] = cond
                    res.append(f)
        except Exception:
            pass
all_results["JNU"] = ("H", res)
print(f"{len(res)} windows")

# MFPT
print("Loading MFPT...", end=" ")
mfpt_dir = os.path.join(HERE, "..", "data", "mfpt")
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath):
            continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"):
                continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0, 0]["gs"].flatten()
                sr = int(d["bearing"][0, 0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs) // sr)):
                    seg = gs[w * sr:(w + 1) * sr]
                    f = analyse_window(seg, sr)
                    if f:
                        f["condition"] = cond
                        res.append(f)
            except Exception:
                pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)} windows")

# MCC5-THU 1000 RPM
print("Loading MCC5 (1000)...", end=" ")
gear_dir = (r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD"
            r"\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU"
            r"\MCC5-THU gearbox fault diagnosis datasets")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        if "speed_circulation_10Nm-1000rpm" not in fname:
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            f = analyse_window(sig[:20480], 20480)
            if f:
                f["condition"] = cond
                res.append(f)
        except Exception:
            pass
all_results["MCC5 (1000)"] = ("H", res)
print(f"{len(res)} windows")

# MCC5-THU all speeds
print("Loading MCC5 (all)...", end=" ")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            f = analyse_window(sig[:20480], 20480)
            if f:
                f["condition"] = cond
                res.append(f)
        except Exception:
            pass
all_results["MCC5 (all)"] = ("H", res)
print(f"{len(res)} windows")


# ------------------------------------------------------------------
#  Compute FDR table
# ------------------------------------------------------------------
print("\n" + "=" * 100)
print(f"  AR(p={AR_ORDER}) PREWHITENING vs PROPOSED SIGMA-FAMILY")
print("=" * 100)
print(f"{'Dataset':<14}{'sigma':>10}{'sigma_norm':>12}{'AR-RMS':>10}"
      f"{'AR-kurt':>10}{'(rule var)':>12}{'(rule FDR)':>12}")

rows = []
for name, (hc, recs) in all_results.items():
    if not recs:
        continue
    h = [r for r in recs if r["condition"] == hc]
    f = [r for r in recs if r["condition"] != hc]
    if not h or not f:
        continue
    r2_mean = float(np.mean([r["r2"] for r in recs if r.get("r2") is not None]))
    fdr_sigma = fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
    fdr_snorm = fdr([r["sigma_norm"] for r in h], [r["sigma_norm"] for r in f])
    fdr_arrms = fdr([r["ar_rms"] for r in h], [r["ar_rms"] for r in f])
    fdr_arkurt = fdr([r["ar_kurt"] for r in h], [r["ar_kurt"] for r in f])
    rule = "sigma_norm" if r2_mean > 0.5 else "sigma"
    fdr_rule = fdr_snorm if rule == "sigma_norm" else fdr_sigma
    print(f"{name:<14}{fdr_sigma:>10.3f}{fdr_snorm:>12.3f}"
          f"{fdr_arrms:>10.3f}{fdr_arkurt:>10.3f}"
          f"{rule:>12}{fdr_rule:>12.3f}")
    rows.append({
        "dataset": name, "r2": r2_mean, "rule": rule,
        "fdr_sigma": fdr_sigma, "fdr_snorm": fdr_snorm,
        "fdr_arrms": fdr_arrms, "fdr_arkurt": fdr_arkurt,
        "fdr_rule": fdr_rule,
    })

# Wins counts
wins_rule_v_arrms = sum(1 for r in rows if r["fdr_rule"] > r["fdr_arrms"])
wins_rule_v_arkurt = sum(1 for r in rows if r["fdr_rule"] > r["fdr_arkurt"])
print(f"\nRule-selected sigma-family vs AR-RMS: rule wins {wins_rule_v_arrms}/{len(rows)}")
print(f"Rule-selected sigma-family vs AR-kurt: rule wins {wins_rule_v_arkurt}/{len(rows)}")

# LaTeX rows
print("\n" + "=" * 100)
print("  LaTeX rows for new AR baselines in Table 2")
print("=" * 100)
arrms_line = "AR-RMS ($p=100$) & \\cite{endo2007enhancement}"
arkurt_line = "AR-kurtosis ($p=100$) & \\cite{endo2007enhancement}"
for r in rows[:6]:  # main table covers six datasets (CWRU..MCC5(all is uncertainty-only))
    arrms_line += f" & {r['fdr_arrms']:.2f}"
    arkurt_line += f" & {r['fdr_arkurt']:.2f}"
arrms_line += " \\\\"
arkurt_line += " \\\\"
print(" ", arrms_line)
print(" ", arkurt_line)

# Save
with open(os.path.join(HERE, "ar_baseline_results.json"), "w") as fh:
    json.dump(rows, fh, indent=2)
print(f"\n  Saved JSON: ar_baseline_results.json")

print("\nDone.")
