"""
AUC and balanced-accuracy analysis for Priority 4.

Goal: compute FDR, ROC-AUC, and balanced accuracy at the FDR-optimal threshold
for the headline indicators on every dataset, and diagnose where FDR and AUC
disagree (e.g. MCC5-THU 1000 RPM, FDR=1.99 vs AUC=0.526).

Headline indicators:
  - sigma_bayes (proposed)
  - sigma_norm  (proposed normalised variant)
  - RMS         (primary statistical baseline)
  - AR-RMS      (AR(100) prewhitening, Endo & Randall)
  - Kurtosis    (raw signal)
  - Residual kurtosis (Yin et al., kurtosis of Bayesian residual)
"""

import os
import sys
import json
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
from scipy.linalg import solve_toeplitz, LinAlgError
from scipy.stats import kurtosis as sp_kurtosis
from functools import partial

print = partial(print, flush=True)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
AR_ORDER = 100


def ar_residual(x, p=AR_ORDER):
    from scipy.signal import lfilter
    x = np.asarray(x, float)
    x = x - np.mean(x)
    N = len(x)
    if N <= p + 10:
        return None
    r = np.correlate(x, x, mode="full")[N - 1: N - 1 + p + 1] / N
    try:
        a = solve_toeplitz(r[:p], r[1:p + 1])
    except LinAlgError:
        return None
    b = np.concatenate(([1.0], -a))
    e = lfilter(b, [1.0], x)
    return e[p:]


def fdr(h, f):
    h, f = np.asarray(h, float), np.asarray(f, float)
    s = np.var(h, ddof=0) + np.var(f, ddof=0)
    return float((np.mean(h) - np.mean(f)) ** 2 / s) if s > 1e-20 else 0.0


def roc_auc(h, f):
    """ROC-AUC for binary classification with 'faulty=1' as positive class.
    Tries both score directions and reports max. Reports >= 0.5 always."""
    h, f = np.asarray(h, float), np.asarray(f, float)
    scores = np.concatenate([h, f])
    labels = np.concatenate([np.zeros(len(h)), np.ones(len(f))])
    order = np.argsort(scores)
    scores_sorted = scores[order]
    labels_sorted = labels[order]
    n_pos = labels.sum()
    n_neg = len(labels) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    # AUC computed by Mann-Whitney U
    ranks = np.empty_like(scores_sorted, dtype=float)
    ranks[np.argsort(order)] = np.arange(1, len(scores) + 1)
    rank_sum_pos = ranks[labels == 1].sum()
    auc_high = (rank_sum_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
    return float(max(auc_high, 1 - auc_high))


def balanced_accuracy(h, f):
    """Balanced accuracy = (TPR + TNR) / 2 at the threshold maximising it."""
    h, f = np.asarray(h, float), np.asarray(f, float)
    if len(h) == 0 or len(f) == 0:
        return float("nan")
    direction = 1 if np.mean(f) >= np.mean(h) else -1
    s_h, s_f = direction * h, direction * f
    candidates = np.unique(np.concatenate([s_h, s_f]))
    best = 0.5
    for t in candidates:
        tpr = np.mean(s_f >= t)
        tnr = np.mean(s_h < t)
        ba = 0.5 * (tpr + tnr)
        if ba > best:
            best = ba
    return float(best)


# ---- compute all features per window ---------------------------------------
def all_features(seg, fs):
    f = bhd.analyze(seg, fs)
    if f is None:
        return None
    seg0 = seg - np.mean(seg)
    f["rms_raw"] = float(np.sqrt(np.mean(seg0 ** 2)))
    f["kurt_raw"] = float(sp_kurtosis(seg0, fisher=True))
    e = ar_residual(seg0)
    if e is None or len(e) == 0:
        return None
    f["ar_rms"] = float(np.sqrt(np.mean(e ** 2)))
    f["ar_kurt"] = float(sp_kurtosis(e, fisher=True))
    return f


# ---- dataset loaders -------------------------------------------------------
all_results = {}


def add(name, hc, recs):
    all_results[name] = (hc, recs)


# CWRU
print("Loading CWRU...", end=" ")
cwru_dir = os.path.join(HERE, "..", "data", "cwru")
cwru_cat = {"97": "N", "98": "N", "99": "N", "100": "N",
            "105": "IR", "106": "IR", "107": "IR", "108": "IR",
            "169": "IR", "170": "IR", "171": "IR", "172": "IR",
            "209": "IR", "210": "IR", "211": "IR", "212": "IR",
            "118": "B", "119": "B", "120": "B", "121": "B",
            "185": "B", "186": "B", "187": "B", "188": "B",
            "222": "B", "223": "B", "224": "B", "225": "B",
            "130": "OR", "131": "OR", "132": "OR", "133": "OR",
            "197": "OR", "198": "OR", "199": "OR", "200": "OR",
            "234": "OR", "235": "OR", "236": "OR", "237": "OR"}
res = []
for fnum, cond in cwru_cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath):
        continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys:
        continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w * 12000:(w + 1) * 12000]
        if len(seg) < 12000:
            break
        f = all_features(seg, 12000)
        if f:
            f["condition"] = cond
            res.append(f)
add("CWRU", "N", res)
print(f"{len(res)} windows")

# Paderborn
print("Loading Paderborn...", end=" ")
pb_dir = os.path.join(HERE, "..", "data", "paderborn")
pb_map = {"K001": "H", "K002": "H", "KA01": "OR", "KA04": "OR",
          "KI01": "IR", "KI04": "IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath):
        bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath):
        continue
    files = sorted([f for f in os.listdir(bpath)
                    if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0, 0]["Y"][0, 6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w * 16000:(w + 1) * 16000]
            if len(seg) < 16000:
                break
            f = all_features(seg, 16000)
            if f:
                f["condition"] = cond
                res.append(f)
add("Paderborn", "H", res)
print(f"{len(res)} windows")

# UOttawa
print("Loading UOttawa...", end=" ")
uo_dir = os.path.join(HERE, "..", "..", "data", "uottawa_mendeley")
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"):
            continue
        cc = fname[0]
        if cc not in "HOIBC":
            continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"):
                continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    f = all_features(data[:20000], 20000)
                    if f:
                        f["condition"] = cond
                        res.append(f)
                break
add("UOttawa", "H", res)
print(f"{len(res)} windows")

# JNU
print("Loading JNU...", end=" ")
jnu_dir = os.path.join(HERE, "..", "data", "jnu")
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"):
            continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1:
                data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data) // 50000)):
                seg = data[w * 50000:(w + 1) * 50000]
                f = all_features(seg, 50000)
                if f:
                    f["condition"] = cond
                    res.append(f)
        except Exception:
            pass
add("JNU", "H", res)
print(f"{len(res)} windows")

# MFPT
print("Loading MFPT...", end=" ")
mfpt_dir = os.path.join(HERE, "..", "data", "mfpt")
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath):
            continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"):
                continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0, 0]["gs"].flatten()
                sr = int(d["bearing"][0, 0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs) // sr)):
                    seg = gs[w * sr:(w + 1) * sr]
                    f = all_features(seg, sr)
                    if f:
                        f["condition"] = cond
                        res.append(f)
            except Exception:
                pass
add("MFPT", "H", res)
print(f"{len(res)} windows")

# MCC5-THU 1000 RPM (matches Table 4 in main.tex)
print("Loading MCC5 (1000)...", end=" ")
gear_dir = (r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD"
            r"\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU"
            r"\MCC5-THU gearbox fault diagnosis datasets")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        if "speed_circulation_10Nm-1000rpm" not in fname:
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            f = all_features(sig[:20480], 20480)
            if f:
                f["condition"] = cond
                res.append(f)
        except Exception:
            pass
add("MCC5", "H", res)
print(f"{len(res)} windows")

# ---------------------------------------------------------------------------
# Compute the metric table
# ---------------------------------------------------------------------------
features = [
    ("sigma_bayes", "sigma"),
    ("sigma_norm", "sigma_norm"),
    ("rms_raw", "RMS"),
    ("ar_rms", "AR-RMS"),
    ("kurt_raw", "Kurtosis"),
    ("resid_kurtosis", "Resid.kurt"),
]

datasets = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]
table = {ds: {} for ds in datasets}

print("\n" + "=" * 110)
print("  FDR / AUC / Balanced accuracy per indicator and dataset")
print("=" * 110)
header = f"{'Dataset':<12}{'Feature':<12}" \
         f"{'FDR':>10}{'AUC':>10}{'BalAcc':>10}{'n_h':>6}{'n_f':>6}"
print(header)
print("-" * len(header))

for ds in datasets:
    if ds not in all_results:
        continue
    hc, recs = all_results[ds]
    h = [r for r in recs if r["condition"] == hc]
    f = [r for r in recs if r["condition"] != hc]
    if not h or not f:
        continue
    for feat_key, feat_name in features:
        hv = [r[feat_key] for r in h if r.get(feat_key) is not None]
        fv = [r[feat_key] for r in f if r.get(feat_key) is not None]
        if not hv or not fv:
            continue
        fd = fdr(hv, fv)
        au = roc_auc(hv, fv)
        ba = balanced_accuracy(hv, fv)
        table[ds][feat_name] = {"fdr": fd, "auc": au, "ba": ba,
                                 "n_h": len(hv), "n_f": len(fv)}
        print(f"{ds:<12}{feat_name:<12}"
              f"{fd:>10.3f}{au:>10.3f}{ba:>10.3f}"
              f"{len(hv):>6}{len(fv):>6}")
    print()

# ---------------------------------------------------------------------------
# LaTeX rows for the new metrics table
# ---------------------------------------------------------------------------
print("=" * 110)
print("  LaTeX: AUC table (parallel to Table 2)")
print("=" * 110)
header_row = "Indicator & " + " & ".join(datasets) + " \\\\"
print("  AUC values")
print(" ", header_row)
for feat_key, feat_name in features:
    cells = []
    for ds in datasets:
        v = table.get(ds, {}).get(feat_name, {})
        au = v.get("auc")
        cells.append("---" if au is None else f"{au:.3f}")
    print(f"  {feat_name} & " + " & ".join(cells) + " \\\\")

print("\n  Balanced accuracy")
print(" ", header_row)
for feat_key, feat_name in features:
    cells = []
    for ds in datasets:
        v = table.get(ds, {}).get(feat_name, {})
        ba = v.get("ba")
        cells.append("---" if ba is None else f"{ba:.3f}")
    print(f"  {feat_name} & " + " & ".join(cells) + " \\\\")

# ---------------------------------------------------------------------------
# Diagnose FDR/AUC disagreement
# ---------------------------------------------------------------------------
print("\n" + "=" * 110)
print("  FDR/AUC disagreement diagnosis (cases where FDR > 1 but AUC < 0.7)")
print("=" * 110)
for ds in datasets:
    for feat_key, feat_name in features:
        v = table.get(ds, {}).get(feat_name, {})
        fd = v.get("fdr"); au = v.get("auc")
        if fd is None or au is None:
            continue
        if fd > 1.0 and au < 0.7:
            # Inspect distribution
            hc, recs = all_results[ds]
            h = [r[feat_key] for r in recs if r["condition"] == hc]
            f = [r[feat_key] for r in recs if r["condition"] != hc]
            h_arr = np.array(h, float)
            f_arr = np.array(f, float)
            print(f"  {ds:<12}{feat_name:<12} FDR={fd:.2f}, AUC={au:.3f}")
            print(f"     Healthy: mean={np.mean(h_arr):.4f}, std={np.std(h_arr):.4f}, "
                  f"min={np.min(h_arr):.4f}, max={np.max(h_arr):.4f}")
            print(f"     Faulty : mean={np.mean(f_arr):.4f}, std={np.std(f_arr):.4f}, "
                  f"min={np.min(f_arr):.4f}, max={np.max(f_arr):.4f}")
            ovl_lo = max(np.min(h_arr), np.min(f_arr))
            ovl_hi = min(np.max(h_arr), np.max(f_arr))
            n_h_in_ovl = int(np.sum((h_arr >= ovl_lo) & (h_arr <= ovl_hi)))
            n_f_in_ovl = int(np.sum((f_arr >= ovl_lo) & (f_arr <= ovl_hi)))
            print(f"     Overlap range [{ovl_lo:.4f}, {ovl_hi:.4f}], "
                  f"healthy in overlap: {n_h_in_ovl}/{len(h_arr)}, "
                  f"faulty in overlap: {n_f_in_ovl}/{len(f_arr)}")

# Save
with open(os.path.join(HERE, "auc_balanced_accuracy.json"), "w") as fh:
    json.dump(table, fh, indent=2)
print("\n  Saved: auc_balanced_accuracy.json")
print("\nDone.")
