"""
Bayesian Harmonic Decomposition for Machinery Fault Diagnosis

Unlike frequentist approaches (Yin 2014, Li 2017) that use least squares + AIC/BIC,
this method uses Bayesian linear regression with conjugate priors to simultaneously
estimate the harmonic amplitudes and the residual variance σ².

Key advantages:
1. σ² is a MODEL PARAMETER with a posterior distribution, not a post-hoc statistic
2. Uncertainty quantification: P(fault) can be computed from the posterior
3. Automatic model complexity control via the prior (no AIC/BIC/AICc needed)
4. Closed-form posterior (no MCMC — exact and fast)

Mathematical framework:
    Signal model:  x = Φθ + ε,  ε ~ N(0, σ²I)

    Priors:
        θ | σ² ~ N(0, σ²/λ · I)     (conjugate normal prior on amplitudes)
        σ²     ~ Inv-Gamma(a₀, b₀)   (conjugate prior on noise variance)

    Posterior (closed-form):
        θ | x, σ² ~ N(μ_n, Σ_n)
        σ² | x    ~ Inv-Gamma(a_n, b_n)

    where:
        Σ_n = (ΦᵀΦ + λI)⁻¹
        μ_n = Σ_n Φᵀx
        a_n = a₀ + N/2
        b_n = b₀ + ½(xᵀx - μ_nᵀ Σ_n⁻¹ μ_n)

    Diagnostic features (from posterior):
        E[σ²]   = b_n / (a_n - 1)           → point estimate of residual variance
        σ       = sqrt(E[σ²])               → harmonic residual (our diagnostic)
        CI(σ²)  = inverse-gamma quantiles    → uncertainty on diagnosis
        log p(x|M) = marginal likelihood     → automatic model selection

Author: Omrane Abdallah, University of Manitoba, 2026
"""

import numpy as np
from scipy.signal import find_peaks
from scipy.special import gammaln
from scipy.stats import invgamma
import time
from functools import partial
print_flush = partial(print, flush=True)


class BayesianHarmonicDiagnostic:
    """
    Bayesian harmonic decomposition for fault diagnosis.

    Uses conjugate Normal-Inverse-Gamma prior for closed-form posterior.
    No MCMC needed — exact inference.
    """

    def __init__(self, max_freqs=80, amplitude_threshold=0.005,
                 prior_precision=1.0, prior_a=1.0, prior_b=1e-4):
        """
        Parameters:
            max_freqs: maximum number of candidate frequencies from FFT
            amplitude_threshold: fraction of max FFT amplitude for peak detection
            prior_precision: λ — controls how strongly amplitudes are regularized toward zero
                            Higher λ = sparser model (fewer effective harmonics)
                            Lower λ = less regularization (more harmonics retained)
            prior_a: a₀ — shape parameter of Inverse-Gamma prior on σ²
                     Small a₀ (e.g. 1) = weak/uninformative prior
            prior_b: b₀ — scale parameter of Inverse-Gamma prior on σ²
                     Small b₀ = prior centered near zero noise
        """
        self.max_freqs = max_freqs
        self.amplitude_threshold = amplitude_threshold
        self.lam = prior_precision  # λ
        self.a0 = prior_a           # a₀
        self.b0 = prior_b           # b₀

    def detect_fft_peaks(self, sig, fs):
        """Detect spectral peaks from FFT — same as frequentist approach."""
        N = len(sig)
        fft_vals = np.fft.rfft(sig)
        fft_mag = np.abs(fft_vals) * 2.0 / N
        freqs = np.fft.rfftfreq(N, 1.0 / fs)
        threshold = self.amplitude_threshold * np.max(fft_mag)
        peaks, props = find_peaks(fft_mag, height=threshold, distance=3)
        if len(peaks) == 0:
            return np.array([]), np.array([])
        heights = props['peak_heights']
        order = np.argsort(heights)[::-1][:self.max_freqs]
        return freqs[peaks[order]], fft_mag[peaks[order]]

    def build_design_matrix(self, sig, fs, peak_freqs):
        """Build Φ matrix: [1, cos(ω₁t), sin(ω₁t), cos(ω₂t), sin(ω₂t), ...]"""
        N = len(sig)
        t = np.arange(N) / fs
        cols = [np.ones(N)]  # DC offset
        for f in peak_freqs:
            cols.append(np.cos(2 * np.pi * f * t))
            cols.append(np.sin(2 * np.pi * f * t))
        return np.column_stack(cols)

    def fit_bayesian(self, sig, Phi):
        """
        Bayesian linear regression with Normal-Inverse-Gamma conjugate prior.

        Returns posterior parameters for θ and σ².
        All computations are closed-form (no sampling).
        """
        N, p = Phi.shape
        x = sig

        # Prior parameters
        lam = self.lam
        a0 = self.a0
        b0 = self.b0

        # Posterior for θ | σ² (Normal)
        # Σ_n = (ΦᵀΦ + λI)⁻¹
        PhiTPhi = Phi.T @ Phi
        Lambda_n = PhiTPhi + lam * np.eye(p)
        Sigma_n = np.linalg.inv(Lambda_n)

        # μ_n = Σ_n Φᵀx
        mu_n = Sigma_n @ (Phi.T @ x)

        # Posterior for σ² (Inverse-Gamma)
        # a_n = a₀ + N/2
        a_n = a0 + N / 2.0

        # b_n = b₀ + ½(xᵀx - μ_nᵀ Λ_n μ_n)
        b_n = b0 + 0.5 * (x @ x - mu_n @ Lambda_n @ mu_n)

        # Marginal likelihood log p(x | M) for model comparison
        # log p(x|M) = -N/2 log(2π) + ½ log|λI| - ½ log|Λ_n| + a₀ log(b₀) - a_n log(b_n)
        #              + log Γ(a_n) - log Γ(a₀)
        sign, logdet_Lambda_n = np.linalg.slogdet(Lambda_n)
        log_marginal = (
            -N / 2.0 * np.log(2 * np.pi)
            + p / 2.0 * np.log(lam)
            - 0.5 * logdet_Lambda_n
            + a0 * np.log(b0) - a_n * np.log(max(b_n, 1e-30))
            + gammaln(a_n) - gammaln(a0)
        )

        return {
            'mu_n': mu_n,           # Posterior mean of θ
            'Sigma_n': Sigma_n,     # Posterior covariance of θ
            'a_n': a_n,             # Posterior shape of σ²
            'b_n': b_n,             # Posterior scale of σ²
            'log_marginal': log_marginal,  # Log marginal likelihood
            'p': p,                 # Number of parameters
            'N': N,                 # Number of data points
        }

    def extract_diagnostics(self, sig, fs, posterior, Phi):
        """
        Extract diagnostic features from the Bayesian posterior.

        Key outputs:
            sigma_mean: E[σ] — point estimate of residual std (the diagnostic)
            sigma_var:  Var[σ] — uncertainty on the diagnostic
            sigma_ci:   95% credible interval for σ
            r2:         coefficient of determination
            sigma_norm: σ / RMS (load-invariant version)
            log_marginal: for model comparison
        """
        N = len(sig)
        rms = np.sqrt(np.mean(sig**2))

        a_n = posterior['a_n']
        b_n = posterior['b_n']
        mu_n = posterior['mu_n']

        # Posterior of σ² is Inverse-Gamma(a_n, b_n)
        # E[σ²] = b_n / (a_n - 1)  for a_n > 1
        if a_n > 1:
            sigma2_mean = b_n / (a_n - 1)
        else:
            sigma2_mean = b_n / a_n  # fallback

        # E[σ] ≈ sqrt(E[σ²]) (approximation; exact requires E[1/sqrt(IG)])
        sigma_mean = np.sqrt(sigma2_mean)

        # Var[σ²] = b_n² / ((a_n-1)²(a_n-2))  for a_n > 2
        if a_n > 2:
            sigma2_var = b_n**2 / ((a_n - 1)**2 * (a_n - 2))
        else:
            sigma2_var = sigma2_mean**2  # fallback

        # 95% credible interval for σ²
        sigma2_ci_low = invgamma.ppf(0.025, a_n, scale=b_n)
        sigma2_ci_high = invgamma.ppf(0.975, a_n, scale=b_n)
        sigma_ci = (np.sqrt(sigma2_ci_low), np.sqrt(sigma2_ci_high))

        # R² from posterior mean prediction
        pred = Phi @ mu_n
        resid = sig - pred
        ss_res = np.sum(resid**2)
        ss_tot = np.sum((sig - np.mean(sig))**2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0

        # Frequentist σ for comparison
        sigma_freq = np.std(resid)

        # Kurtosis of residual for comparison with Yin
        if sigma_freq > 1e-20:
            resid_kurtosis = float(np.mean(((resid - np.mean(resid)) / sigma_freq)**4) - 3)
        else:
            resid_kurtosis = 0

        # Normalized versions
        sigma_norm = sigma_mean / rms if rms > 1e-20 else 0
        sigma_norm_freq = sigma_freq / rms if rms > 1e-20 else 0

        # Raw signal kurtosis
        raw_kurtosis = float(np.mean(((sig - np.mean(sig)) / np.std(sig))**4) - 3) if np.std(sig) > 1e-20 else 0

        return {
            # Bayesian diagnostics (NEW)
            'sigma_bayes': sigma_mean,          # E[σ] from posterior
            'sigma_bayes_ci_low': sigma_ci[0],  # 95% CI lower
            'sigma_bayes_ci_high': sigma_ci[1], # 95% CI upper
            'sigma2_var': sigma2_var,           # Var[σ²] — uncertainty
            'log_marginal': posterior['log_marginal'],  # Model evidence

            # Standard diagnostics (for comparison)
            'sigma': sigma_freq,                # Frequentist σ (std of residual)
            'sigma_norm': sigma_norm_freq,      # σ / RMS
            'r2': r2,
            'rms': rms,
            'resid_kurtosis': resid_kurtosis,   # Yin's feature
            'raw_kurtosis': raw_kurtosis,
            'n_freqs': (posterior['p'] - 1) // 2,
        }

    def analyze(self, sig, fs, verbose=False):
        """
        Full Bayesian harmonic analysis of a vibration signal.

        Steps:
            1. FFT peak detection (same as frequentist)
            2. Build design matrix Φ
            3. Bayesian inference (closed-form)
            4. Extract diagnostics from posterior

        Returns dict of diagnostic features.
        """
        t0 = time.time()

        # Remove DC
        sig = sig - np.mean(sig)

        # Step 1: Detect peaks
        peak_freqs, peak_amps = self.detect_fft_peaks(sig, fs)
        if len(peak_freqs) == 0:
            return None

        # Step 2: Build design matrix with ALL detected peaks
        # The Bayesian prior handles regularization — no need for forward selection
        Phi = self.build_design_matrix(sig, fs, peak_freqs)

        # Step 3: Bayesian inference (closed-form, instant)
        posterior = self.fit_bayesian(sig, Phi)

        # Step 4: Extract diagnostics
        diagnostics = self.extract_diagnostics(sig, fs, posterior, Phi)
        diagnostics['elapsed'] = time.time() - t0
        diagnostics['n_candidates'] = len(peak_freqs)

        if verbose:
            print(f"    Peaks: {len(peak_freqs)}, Params: {posterior['p']}, "
                  f"σ_bayes={diagnostics['sigma_bayes']:.6f} "
                  f"[{diagnostics['sigma_bayes_ci_low']:.6f}, {diagnostics['sigma_bayes_ci_high']:.6f}], "
                  f"R²={diagnostics['r2']:.3f}, "
                  f"σ_freq={diagnostics['sigma']:.6f}, "
                  f"time={diagnostics['elapsed']:.3f}s")

        return diagnostics

    def automatic_model_selection(self, sig, fs, lambda_values=None):
        """
        Use marginal likelihood to automatically select the best prior precision λ.
        This replaces AIC/BIC/AICc — the Bayesian model evidence does the selection.

        Returns the best λ and corresponding diagnostics.
        """
        if lambda_values is None:
            lambda_values = [0.01, 0.1, 1.0, 10.0, 100.0, 1000.0]

        sig = sig - np.mean(sig)
        peak_freqs, _ = self.detect_fft_peaks(sig, fs)
        if len(peak_freqs) == 0:
            return None

        Phi = self.build_design_matrix(sig, fs, peak_freqs)

        best_lml = -np.inf
        best_result = None
        best_lambda = None

        for lam in lambda_values:
            self.lam = lam
            posterior = self.fit_bayesian(sig, Phi)
            if posterior['log_marginal'] > best_lml:
                best_lml = posterior['log_marginal']
                best_result = posterior
                best_lambda = lam

        self.lam = best_lambda
        diagnostics = self.extract_diagnostics(sig, fs, best_result, Phi)
        diagnostics['best_lambda'] = best_lambda
        diagnostics['log_marginal'] = best_lml

        return diagnostics


def fdr(h, f):
    """Fisher Discriminant Ratio."""
    mu_h, s_h = np.mean(h), np.std(h)
    mu_f, s_f = np.mean(f), np.std(f)
    d = s_h**2 + s_f**2
    return (mu_h - mu_f)**2 / d if d > 1e-20 else 0

def auc(h, f):
    """Area Under ROC Curve."""
    labels = np.array([0]*len(h) + [1]*len(f))
    scores = np.array(list(h) + list(f))
    thr = np.sort(np.unique(scores))
    tpr_a, fpr_a = [], []
    for t in thr:
        tpr_a.append(np.sum(scores[labels==1] >= t) / np.sum(labels==1))
        fpr_a.append(np.sum(scores[labels==0] >= t) / np.sum(labels==0))
    o = np.argsort(fpr_a)
    return float(np.trapezoid(np.array(tpr_a)[o], np.array(fpr_a)[o]))


if __name__ == "__main__":
    import scipy.io as sio
    import scipy.signal as sig_proc
    import os

    print("="*80)
    print("  BAYESIAN HARMONIC DIAGNOSTIC — TEST ON ALL DATASETS")
    print("="*80)

    bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)

    all_results = {}

    # === CWRU ===
    print("\nCWRU...", end=" ")
    cwru_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\cwru"
    cat = {"97":"N","98":"N","99":"N","100":"N","105":"IR","106":"IR","107":"IR","108":"IR",
           "169":"IR","170":"IR","171":"IR","172":"IR","209":"IR","210":"IR","211":"IR","212":"IR",
           "118":"B","119":"B","120":"B","121":"B","185":"B","186":"B","187":"B","188":"B",
           "222":"B","223":"B","224":"B","225":"B","130":"OR","131":"OR","132":"OR","133":"OR",
           "197":"OR","198":"OR","199":"OR","200":"OR","234":"OR","235":"OR","236":"OR","237":"OR"}
    res = []
    for fnum, cond in cat.items():
        fpath = os.path.join(cwru_dir, f"{fnum}.mat")
        if not os.path.exists(fpath): continue
        d = sio.loadmat(fpath)
        keys = [k for k in d.keys() if "DE_time" in k]
        if not keys: continue
        data = d[keys[0]].flatten()
        for w in range(4):
            seg = data[w*12000:(w+1)*12000]
            if len(seg) < 12000: break
            feats = bhd.analyze(seg, 12000)
            if feats: feats["condition"] = cond; res.append(feats)
    all_results["CWRU"] = ("N", res)
    print(f"{len(res)} measurements")

    # === PADERBORN ===
    print("Paderborn...", end=" ")
    pb_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\paderborn"
    pb_map = {"K001":"H","K002":"H","KA01":"OR","KA04":"OR","KI01":"IR","KI04":"IR"}
    res = []
    for bearing, cond in pb_map.items():
        bpath = os.path.join(pb_dir, bearing, bearing)
        if not os.path.exists(bpath): bpath = os.path.join(pb_dir, bearing)
        if not os.path.exists(bpath): continue
        files = sorted([f for f in os.listdir(bpath) if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
        for fname in files:
            d = sio.loadmat(os.path.join(bpath, fname))
            key = [k for k in d.keys() if not k.startswith("_")][0]
            raw = d[key][0,0]["Y"][0,6]["Data"].flatten()
            data = sig_proc.decimate(raw, 4)
            for w in range(3):
                seg = data[w*16000:(w+1)*16000]
                if len(seg) < 16000: break
                feats = bhd.analyze(seg, 16000)
                if feats: feats["condition"] = cond; feats["bearing"] = bearing; res.append(feats)
    all_results["Paderborn"] = ("H", res)
    print(f"{len(res)} measurements")

    # === UOTTAWA ===
    print("UOttawa...", end=" ")
    uo_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\data\uottawa_mendeley"
    res = []
    if os.path.exists(uo_dir):
        for fname in sorted(os.listdir(uo_dir)):
            if not fname.endswith(".mat"): continue
            cc = fname[0]
            if cc not in "HOIBC": continue
            cond = "H" if cc == "H" else "F"
            d = sio.loadmat(os.path.join(uo_dir, fname))
            for key in d:
                if key.startswith("_"): continue
                arr = d[key]
                if hasattr(arr, "shape") and arr.size > 1000:
                    data = sig_proc.decimate(arr.flatten(), 10)
                    if len(data) >= 20000:
                        feats = bhd.analyze(data[:20000], 20000)
                        if feats: feats["condition"] = cond; feats["fault_type"] = cc; res.append(feats)
                    break
    all_results["UOttawa"] = ("H", res)
    print(f"{len(res)} measurements")

    # === MCC5-THU GEAR ===
    print("MCC5-THU gear...", end=" ")
    gear_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU\MCC5-THU gearbox fault diagnosis datasets"
    res = []
    if os.path.exists(gear_dir):
        for fname in sorted(os.listdir(gear_dir)):
            if not fname.endswith(".csv"): continue
            if "speed_circulation_10Nm-1000rpm" not in fname: continue
            cond = "H" if fname.startswith("health") else "F"
            try:
                data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
                sig = data[:, 5]  # gearbox_vibration_x
                win_len = min(20480, len(sig))
                feats = bhd.analyze(sig[:win_len], 20480)
                if feats: feats["condition"] = cond; feats["filename"] = fname; res.append(feats)
            except: pass
    all_results["MCC5-THU"] = ("H", res)
    print(f"{len(res)} measurements")

    # === RESULTS ===
    print("\n" + "="*90)
    print("  BAYESIAN vs FREQUENTIST: σ_bayes vs σ_freq vs kurtosis(resid)")
    print("="*90)

    print(f"\n  {'Dataset':<12s} | {'σ_bayes':>10s} {'σ_freq':>10s} {'ResKurt':>10s} | {'σ_bayes':>10s} {'σ_freq':>10s} {'ResKurt':>10s} | {'R2':>5s}")
    print(f"  {'':>12s} | {'FDR':>10s} {'FDR':>10s} {'FDR':>10s} | {'AUC':>10s} {'AUC':>10s} {'AUC':>10s} |")
    print(f"  {'-'*12}-+-{'-'*10}-{'-'*10}-{'-'*10}-+-{'-'*10}-{'-'*10}-{'-'*10}-+-{'-'*5}")

    for name in ["CWRU", "Paderborn", "UOttawa", "MCC5-THU"]:
        hc, results = all_results[name]
        if not results: continue
        h = [r for r in results if r["condition"] == hc]
        f = [r for r in results if r["condition"] != hc]
        if not h or not f: continue

        sb_fdr = fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
        sb_auc = auc([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
        sf_fdr = fdr([r["sigma"] for r in h], [r["sigma"] for r in f])
        sf_auc = auc([r["sigma"] for r in h], [r["sigma"] for r in f])
        kf_fdr = fdr([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
        kf_auc = auc([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
        r2m = np.mean([r["r2"] for r in results])

        print(f"  {name:<12s} | {sb_fdr:>10.3f} {sf_fdr:>10.3f} {kf_fdr:>10.3f} | {sb_auc:>10.3f} {sf_auc:>10.3f} {kf_auc:>10.3f} | {r2m:>5.3f}")

    # Show Bayesian uncertainty examples
    print(f"\n  UNCERTAINTY QUANTIFICATION (Bayesian 95% CI for σ):")
    for name in ["CWRU", "Paderborn", "MCC5-THU"]:
        hc, results = all_results[name]
        if not results: continue
        h = [r for r in results if r["condition"] == hc]
        f = [r for r in results if r["condition"] != hc]
        if not h or not f: continue

        h_mean = np.mean([r["sigma_bayes"] for r in h])
        h_ci_low = np.mean([r["sigma_bayes_ci_low"] for r in h])
        h_ci_high = np.mean([r["sigma_bayes_ci_high"] for r in h])
        f_mean = np.mean([r["sigma_bayes"] for r in f])
        f_ci_low = np.mean([r["sigma_bayes_ci_low"] for r in f])
        f_ci_high = np.mean([r["sigma_bayes_ci_high"] for r in f])

        overlap = "NO OVERLAP" if h_ci_high < f_ci_low else "OVERLAP"

        print(f"  {name:<12s}: H = {h_mean:.6f} [{h_ci_low:.6f}, {h_ci_high:.6f}]  "
              f"F = {f_mean:.6f} [{f_ci_low:.6f}, {f_ci_high:.6f}]  → {overlap}")

    # Paderborn per-bearing with uncertainty
    print(f"\n  PADERBORN PER BEARING (with Bayesian uncertainty):")
    hc, pb = all_results["Paderborn"]
    for bearing in ["K001", "K002", "KA01", "KA04", "KI01", "KI04"]:
        sub = [r for r in pb if r.get("bearing") == bearing]
        if sub:
            sb = np.mean([r["sigma_bayes"] for r in sub])
            ci_l = np.mean([r["sigma_bayes_ci_low"] for r in sub])
            ci_h = np.mean([r["sigma_bayes_ci_high"] for r in sub])
            rk = np.mean([r["resid_kurtosis"] for r in sub])
            print(f"    {bearing}: σ_bayes = {sb:.4f} [{ci_l:.4f}, {ci_h:.4f}]  resid_kurt = {rk:.2f}")

    # Timing
    print(f"\n  TIMING:")
    for name in ["CWRU", "Paderborn", "UOttawa", "MCC5-THU"]:
        hc, results = all_results[name]
        if results:
            avg_time = np.mean([r.get("elapsed", 0) for r in results])
            print(f"    {name}: {avg_time:.3f}s per window")

    print("\nDone!")
