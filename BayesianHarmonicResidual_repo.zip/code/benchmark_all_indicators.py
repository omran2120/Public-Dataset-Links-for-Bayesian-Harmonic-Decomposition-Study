"""
Comprehensive benchmark: Our Bayesian σ vs ALL state-of-the-art indicators.

Indicators tested:
1. σ (Bayesian posterior) — OURS
2. σ_norm — OURS
3. RMS — basic
4. Kurtosis — basic
5. Crest factor — basic
6. Envelope kurtosis — Hilbert transform
7. Spectral kurtosis (mean SK) — Antoni 2006
8. Kurtogram (max SK over bands) — Antoni 2007
9. Infogram (negentropy) — Antoni 2016
10. Residual kurtosis — Yin 2014
"""
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
from scipy.signal import find_peaks, hilbert, stft
from scipy.stats import kurtosis as sp_kurtosis
import os, sys
from functools import partial
print = partial(print, flush=True)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'bayesian_approach'))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)


def compute_all_indicators(sig, fs):
    """Compute ALL fault indicators for one signal window."""
    sig = sig - np.mean(sig)
    N = len(sig)
    rms = np.sqrt(np.mean(sig**2))
    if rms < 1e-20:
        return None

    results = {}

    # === BAYESIAN σ (ours) ===
    bh = bhd.analyze(sig, fs)
    if bh is None:
        return None
    results['sigma_bayes'] = bh['sigma_bayes']
    results['sigma_norm'] = bh['sigma_norm']
    results['r2'] = bh['r2']
    results['resid_kurtosis'] = bh['resid_kurtosis']  # Yin's feature
    results['sigma_bayes_ci_low'] = bh['sigma_bayes_ci_low']
    results['sigma_bayes_ci_high'] = bh['sigma_bayes_ci_high']

    # === BASIC TIME-DOMAIN ===
    results['rms'] = rms
    results['kurtosis'] = float(sp_kurtosis(sig, fisher=True))
    results['crest_factor'] = np.max(np.abs(sig)) / rms

    # === ENVELOPE KURTOSIS (Hilbert) ===
    analytic = hilbert(sig)
    envelope = np.abs(analytic)
    envelope_dc = envelope - np.mean(envelope)
    results['envelope_kurtosis'] = float(sp_kurtosis(envelope_dc, fisher=True))
    results['envelope_rms'] = np.sqrt(np.mean(envelope_dc**2))

    # === SPECTRAL KURTOSIS (Antoni 2006) — mean SK ===
    nperseg = min(256, N // 4)
    noverlap = nperseg * 3 // 4
    f_stft, t_stft, Zxx = stft(sig, fs=fs, nperseg=nperseg, noverlap=noverlap)
    S = np.abs(Zxx)**2  # power spectrogram
    # SK per frequency bin: E[|S|^4] / E[|S|^2]^2 - 2
    S_mean2 = np.mean(S, axis=1)**2
    S_mean4 = np.mean(S**2, axis=1)
    with np.errstate(divide='ignore', invalid='ignore'):
        sk = np.where(S_mean2 > 1e-30, S_mean4 / S_mean2 - 2, 0)
    results['spectral_kurtosis_mean'] = float(np.mean(sk[1:]))  # exclude DC
    results['spectral_kurtosis_max'] = float(np.max(sk[1:]))

    # === KURTOGRAM (Antoni 2007) — max SK over dyadic bands ===
    # Simplified kurtogram: compute SK for different window sizes
    best_sk = -np.inf
    for win_size in [32, 64, 128, 256, 512]:
        if win_size > N // 4:
            continue
        overlap = win_size * 3 // 4
        _, _, Zk = stft(sig, fs=fs, nperseg=win_size, noverlap=overlap)
        Sk = np.abs(Zk)**2
        Sk_m2 = np.mean(Sk, axis=1)**2
        Sk_m4 = np.mean(Sk**2, axis=1)
        with np.errstate(divide='ignore', invalid='ignore'):
            sk_k = np.where(Sk_m2 > 1e-30, Sk_m4 / Sk_m2 - 2, 0)
        max_sk = float(np.max(sk_k[1:]))
        if max_sk > best_sk:
            best_sk = max_sk
    results['kurtogram'] = best_sk

    # === INFOGRAM (Antoni 2016) — negentropy over bands ===
    # Negentropy ≈ 1/12 * E[x^3]^2 + 1/48 * (E[x^4] - 3)^2 (approximation)
    # Compute over dyadic STFT bands
    best_negentropy = -np.inf
    for win_size in [64, 128, 256, 512]:
        if win_size > N // 4:
            continue
        overlap = win_size * 3 // 4
        _, _, Zi = stft(sig, fs=fs, nperseg=win_size, noverlap=overlap)
        Si = np.abs(Zi)  # amplitude spectrum
        for freq_idx in range(1, Si.shape[0]):
            band_signal = Si[freq_idx, :]
            if np.std(band_signal) < 1e-20:
                continue
            band_norm = (band_signal - np.mean(band_signal)) / np.std(band_signal)
            skewness = np.mean(band_norm**3)
            kurt_excess = np.mean(band_norm**4) - 3
            negentropy = (1.0/12) * skewness**2 + (1.0/48) * kurt_excess**2
            if negentropy > best_negentropy:
                best_negentropy = negentropy
    results['infogram'] = best_negentropy if best_negentropy > -np.inf else 0

    # === SQUARED ENVELOPE SPECTRUM (SES) — peak energy ===
    # Compute envelope, then FFT of envelope
    env_spectrum = np.abs(np.fft.rfft(envelope_dc))**2
    env_freqs = np.fft.rfftfreq(N, 1.0/fs)
    # Total SES energy (sum of top 10 peaks)
    ses_peaks_idx = np.argsort(env_spectrum[1:])[-10:] + 1
    results['ses_energy'] = float(np.sum(env_spectrum[ses_peaks_idx]))
    # SES peak amplitude
    results['ses_peak'] = float(np.max(env_spectrum[1:]))

    # === AR PREWHITENING (Endo & Randall 2007) ===
    # Fit AR(p) by least squares, take residual, compute RMS and kurtosis.
    # p=100 is the standard AR order for bearing vibration (Endo & Randall 2007,
    # Sawalhi et al. 2007). Longer orders improve whitening at high fs but
    # cost compute; p=100 balances both for fs up to 100 kHz.
    p_ar = 100
    if N > 2 * p_ar:
        # Build lag matrix: y[t] = sum_{k=1..p} a_k * y[t-k] + e[t]
        X_lag = np.column_stack([sig[p_ar - k - 1 : N - k - 1] for k in range(p_ar)])
        y_ar = sig[p_ar:]
        try:
            coeffs, *_ = np.linalg.lstsq(X_lag, y_ar, rcond=None)
            ar_resid = y_ar - X_lag @ coeffs
            results['ar_rms'] = float(np.sqrt(np.mean(ar_resid**2)))
            results['ar_kurtosis'] = float(sp_kurtosis(ar_resid, fisher=True))
        except np.linalg.LinAlgError:
            results['ar_rms'] = 0.0
            results['ar_kurtosis'] = 0.0
    else:
        results['ar_rms'] = 0.0
        results['ar_kurtosis'] = 0.0

    return results


def fdr(h, f):
    mu_h, s_h = np.mean(h), np.std(h)
    mu_f, s_f = np.mean(f), np.std(f)
    d = s_h**2 + s_f**2
    return (mu_h - mu_f)**2 / d if d > 1e-20 else 0

def auc(h, f):
    labels = np.array([0]*len(h) + [1]*len(f))
    scores = np.array(list(h) + list(f))
    thr = np.sort(np.unique(scores))
    tpr_a, fpr_a = [], []
    for t in thr:
        tpr_a.append(np.sum(scores[labels==1] >= t) / np.sum(labels==1))
        fpr_a.append(np.sum(scores[labels==0] >= t) / np.sum(labels==0))
    o = np.argsort(fpr_a)
    return float(np.trapezoid(np.array(tpr_a)[o], np.array(fpr_a)[o]))


all_results = {}

# === CWRU ===
print("1. CWRU...", end=" ")
cwru_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'cwru')
cat = {"97":"N","98":"N","99":"N","100":"N","105":"IR","106":"IR","107":"IR","108":"IR",
       "169":"IR","170":"IR","171":"IR","172":"IR","209":"IR","210":"IR","211":"IR","212":"IR",
       "118":"B","119":"B","120":"B","121":"B","185":"B","186":"B","187":"B","188":"B",
       "222":"B","223":"B","224":"B","225":"B","130":"OR","131":"OR","132":"OR","133":"OR",
       "197":"OR","198":"OR","199":"OR","200":"OR","234":"OR","235":"OR","236":"OR","237":"OR"}
res = []
for fnum, cond in cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath): continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys: continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w*12000:(w+1)*12000]
        if len(seg) < 12000: break
        feats = compute_all_indicators(seg, 12000)
        if feats: feats["condition"] = cond; res.append(feats)
all_results["CWRU"] = ("N", res)
print(f"{len(res)}")

# === PADERBORN ===
print("2. Paderborn...", end=" ")
pb_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'paderborn')
pb_map = {"K001":"H","K002":"H","KA01":"OR","KA04":"OR","KI01":"IR","KI04":"IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath): bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath): continue
    files = sorted([f for f in os.listdir(bpath) if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0,0]["Y"][0,6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w*16000:(w+1)*16000]
            if len(seg) < 16000: break
            feats = compute_all_indicators(seg, 16000)
            if feats: feats["condition"] = cond; feats["bearing"] = bearing; res.append(feats)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)}")

# === UOTTAWA ===
print("3. UOttawa...", end=" ")
uo_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\data\uottawa_mendeley"
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"): continue
        cc = fname[0]
        if cc not in "HOIBC": continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"): continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    feats = compute_all_indicators(data[:20000], 20000)
                    if feats: feats["condition"] = cond; res.append(feats)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)}")

# === JNU ===
print("4. JNU...", end=" ")
jnu_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'jnu')
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"): continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1: data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data)//50000)):
                seg = data[w*50000:(w+1)*50000]
                feats = compute_all_indicators(seg, 50000)
                if feats: feats["condition"] = cond; res.append(feats)
        except: pass
all_results["JNU"] = ("H", res)
print(f"{len(res)}")

# === MFPT ===
print("5. MFPT...", end=" ")
mfpt_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'mfpt')
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath): continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"): continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0,0]["gs"].flatten()
                sr = int(d["bearing"][0,0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs)//sr)):
                    seg = gs[w*sr:(w+1)*sr]
                    feats = compute_all_indicators(seg, sr)
                    if feats: feats["condition"] = cond; res.append(feats)
            except: pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)}")

# === MCC5-THU ===
print("6. MCC5-THU...", end=" ")
gear_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU\MCC5-THU gearbox fault diagnosis datasets"
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"): continue
        if "speed_circulation_10Nm-1000rpm" not in fname: continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
            sig = data[:, 5]
            feats = compute_all_indicators(sig[:20480], 20480)
            if feats: feats["condition"] = cond; res.append(feats)
        except: pass
all_results["MCC5"] = ("H", res)
print(f"{len(res)}")

# ============================================================
# COMPREHENSIVE RESULTS TABLE
# ============================================================
print("\n" + "="*120)
print("  COMPREHENSIVE BENCHMARK: ALL INDICATORS ACROSS ALL DATASETS")
print("="*120)

all_features = [
    ('sigma_bayes', 'σ (Bayesian)', 'OURS'),
    ('sigma_norm', 'σ_norm', 'OURS'),
    ('rms', 'RMS', 'Basic'),
    ('kurtosis', 'Kurtosis', 'Basic'),
    ('crest_factor', 'Crest factor', 'Basic'),
    ('envelope_kurtosis', 'Env. kurtosis', 'Hilbert'),
    ('spectral_kurtosis_mean', 'SK mean', 'Antoni06'),
    ('kurtogram', 'Kurtogram', 'Antoni07'),
    ('infogram', 'Infogram', 'Antoni16'),
    ('resid_kurtosis', 'Resid. kurt.', 'Yin14'),
    ('ar_rms', 'AR-RMS (p=100)', 'Endo07'),
    ('ar_kurtosis', 'AR-kurt (p=100)', 'Endo07'),
    ('ses_energy', 'SES energy', 'Randall11'),
]

datasets = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]

# Print FDR table
print(f"\n  FDR TABLE:")
header = f"  {'Indicator':<18s} {'Source':<10s}"
for ds in datasets:
    header += f" | {ds:>10s}"
header += " | Wins"
print(header)
print("  " + "-"*len(header))

wins_count = {feat_key: 0 for feat_key, _, _ in all_features}

for feat_key, feat_name, source in all_features:
    line = f"  {feat_name:<18s} {source:<10s}"
    for ds in datasets:
        if ds not in all_results:
            line += f" | {'---':>10s}"
            continue
        hc, results = all_results[ds]
        h = [r for r in results if r["condition"] == hc]
        f = [r for r in results if r["condition"] != hc]
        if not h or not f:
            line += f" | {'---':>10s}"
            continue
        hv = [r[feat_key] for r in h]
        fv = [r[feat_key] for r in f]
        fd = fdr(hv, fv)
        line += f" | {fd:>10.3f}"
    print(line)

# Find winner per dataset
print(f"\n  WINNER PER DATASET (by FDR):")
for ds in datasets:
    if ds not in all_results: continue
    hc, results = all_results[ds]
    h = [r for r in results if r["condition"] == hc]
    f = [r for r in results if r["condition"] != hc]
    if not h or not f: continue

    best_fdr = -1
    best_name = ""
    best_source = ""
    for feat_key, feat_name, source in all_features:
        hv = [r[feat_key] for r in h]
        fv = [r[feat_key] for r in f]
        fd = fdr(hv, fv)
        if fd > best_fdr:
            best_fdr = fd
            best_name = feat_name
            best_source = source
    print(f"    {ds:>12s}: {best_name} ({best_source}) FDR = {best_fdr:.3f}")

# AUC table
print(f"\n  AUC TABLE:")
header = f"  {'Indicator':<18s} {'Source':<10s}"
for ds in datasets:
    header += f" | {ds:>10s}"
print(header)
print("  " + "-"*len(header))

for feat_key, feat_name, source in all_features:
    line = f"  {feat_name:<18s} {source:<10s}"
    for ds in datasets:
        if ds not in all_results:
            line += f" | {'---':>10s}"
            continue
        hc, results = all_results[ds]
        h = [r for r in results if r["condition"] == hc]
        f = [r for r in results if r["condition"] != hc]
        if not h or not f:
            line += f" | {'---':>10s}"
            continue
        hv = [r[feat_key] for r in h]
        fv = [r[feat_key] for r in f]
        au = auc(hv, fv)
        line += f" | {au:>10.3f}"
    print(line)

# Count wins
print(f"\n  WINS COUNT (by FDR):")
win_tracker = {}
for ds in datasets:
    if ds not in all_results: continue
    hc, results = all_results[ds]
    h = [r for r in results if r["condition"] == hc]
    f = [r for r in results if r["condition"] != hc]
    if not h or not f: continue
    best_fdr = -1
    best_key = ""
    for feat_key, feat_name, source in all_features:
        hv = [r[feat_key] for r in h]
        fv = [r[feat_key] for r in f]
        fd = fdr(hv, fv)
        if fd > best_fdr:
            best_fdr = fd
            best_key = feat_name
    win_tracker[best_key] = win_tracker.get(best_key, 0) + 1

for feat_name, count in sorted(win_tracker.items(), key=lambda x: -x[1]):
    print(f"    {feat_name:<18s}: {count}/{len(datasets)}")

# ============================================================
# ACROSS-MEASUREMENT 95% INTERVALS FOR sigma (Priority 1 analysis)
# ------------------------------------------------------------
# Empirical 2.5% / 97.5% sample quantiles of sigma within each class,
# per dataset. This is the interval that governs practical class
# separation in the revised Section 4.2 (eq ci_across).
# ============================================================
import json

ci_rows = []
print("\n" + "="*80)
print("  ACROSS-MEASUREMENT 95% EMPIRICAL INTERVALS (Table tab:uncertainty_across)")
print("="*80)
print(f"  {'Dataset':<14s}  {'Healthy mean':>12s}  {'Healthy CI':>20s}  "
      f"{'Faulty mean':>12s}  {'Faulty CI':>20s}  {'Overlap?':>10s}")
print("  " + "-"*96)

def _fmt_ci(lo, hi):
    return f"[{lo:.4f}, {hi:.4f}]"

def _overlap(h_lo, h_hi, f_lo, f_hi):
    # True separation requires one class's upper quantile to sit
    # entirely below the other class's lower quantile.
    if h_hi < f_lo or f_hi < h_lo:
        return "No"
    overlap_lo = max(h_lo, f_lo)
    overlap_hi = min(h_hi, f_hi)
    overlap_width = overlap_hi - overlap_lo
    class_span = max(h_hi, f_hi) - min(h_lo, f_lo)
    if class_span > 1e-30:
        frac = overlap_width / class_span
        return f"Yes ({frac*100:.1f}%)"
    return "Yes"

quantiles_json = {}

for ds in datasets:
    if ds not in all_results:
        continue
    hc, results = all_results[ds]
    h_sigmas = np.array([r["sigma_bayes"] for r in results if r["condition"] == hc])
    f_sigmas = np.array([r["sigma_bayes"] for r in results if r["condition"] != hc])
    if len(h_sigmas) == 0 or len(f_sigmas) == 0:
        continue
    h_lo, h_hi = np.quantile(h_sigmas, [0.025, 0.975])
    f_lo, f_hi = np.quantile(f_sigmas, [0.025, 0.975])
    h_mu = float(np.mean(h_sigmas))
    f_mu = float(np.mean(f_sigmas))
    overlap = _overlap(h_lo, h_hi, f_lo, f_hi)
    print(f"  {ds:<14s}  {h_mu:>12.4f}  {_fmt_ci(h_lo, h_hi):>20s}  "
          f"{f_mu:>12.4f}  {_fmt_ci(f_lo, f_hi):>20s}  {overlap:>10s}")

    ci_rows.append({
        "dataset": ds,
        "n_healthy": int(len(h_sigmas)),
        "n_faulty": int(len(f_sigmas)),
        "healthy_mean": h_mu,
        "healthy_q025": float(h_lo),
        "healthy_q975": float(h_hi),
        "faulty_mean": f_mu,
        "faulty_q025": float(f_lo),
        "faulty_q975": float(f_hi),
        "overlap": overlap,
    })
    quantiles_json[ds] = {
        "healthy_sigmas": h_sigmas.tolist(),
        "faulty_sigmas": f_sigmas.tolist(),
    }

# Emit LaTeX rows that can be pasted directly into tab:uncertainty_across
print("\n  LaTeX rows for Table tab:uncertainty_across:")
for row in ci_rows:
    ds = row["dataset"]
    ds_label = {"CWRU": "CWRU", "Paderborn": "Paderborn", "UOttawa": "UOttawa",
                "JNU": "JNU", "MFPT": "MFPT", "MCC5": "MCC5 (1000)"}.get(ds, ds)
    print(f"    {ds_label} & {row['healthy_mean']:.3f} "
          f"[{row['healthy_q025']:.3f}, {row['healthy_q975']:.3f}] & "
          f"{row['faulty_mean']:.3f} [{row['faulty_q025']:.3f}, {row['faulty_q975']:.3f}] & "
          f"{row['overlap']} \\\\")

# Persist raw arrays so Figure 4 regeneration can reuse them without rerunning
out_json = os.path.join(os.path.dirname(__file__), "sigma_across_measurement.json")
with open(out_json, "w") as fh:
    json.dump(quantiles_json, fh, indent=2)
print(f"\n  Wrote per-window sigma arrays to: {out_json}")

print("\nDone!")
print("  (For λ-sensitivity and marginal-likelihood selection analysis,")
print("   run lambda_sensitivity.py separately — Priority 7.)")
