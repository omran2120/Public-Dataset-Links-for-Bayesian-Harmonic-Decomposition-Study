"""
Empirical across-measurement CI analysis for the Bayesian Harmonic Residual paper.

For each dataset and class (healthy/faulty), computes:
  - Mean of sigma (already in main.tex)
  - Within-window 95% CI (mean of per-measurement Inv-Gamma quantiles, already in main.tex)
  - Across-measurement 95% CI = empirical 2.5% and 97.5% quantiles of sigma values
  - Across-measurement 68% CI = empirical 16% and 84% quantiles (1-sigma band, for figure)

Outputs:
  - figures/fig_uncertainty_ci.pdf (revised, two-panel: within-window vs across-measurement)
  - empirical_ci_results.txt (LaTeX table rows and summary numbers)
  - empirical_ci_results.json (raw sigma arrays per class, for downstream use)
"""

import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import scipy.io as sio
import scipy.signal as sig_proc
from functools import partial

print = partial(print, flush=True)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)

fig_dir = os.path.join(HERE, "figures")
os.makedirs(fig_dir, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 11,
    "axes.labelsize": 13,
    "axes.titlesize": 13,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 10,
    "figure.dpi": 300,
})


# ------------------------------------------------------------------
#  Data loading (same logic as generate_all_figures.py)
# ------------------------------------------------------------------
all_results = {}


def _collect(feats_list, cond, extra=None):
    out = []
    for f in feats_list:
        if f is None:
            continue
        rec = {"sigma_bayes": f["sigma_bayes"],
               "sigma_bayes_ci_low": f["sigma_bayes_ci_low"],
               "sigma_bayes_ci_high": f["sigma_bayes_ci_high"],
               "condition": cond}
        if extra:
            rec.update(extra)
        out.append(rec)
    return out


# --- CWRU ---
print("Loading CWRU...", end=" ")
cwru_dir = os.path.join(HERE, "..", "data", "cwru")
cwru_cat = {"97": "N", "98": "N", "99": "N", "100": "N",
            "105": "IR", "106": "IR", "107": "IR", "108": "IR",
            "169": "IR", "170": "IR", "171": "IR", "172": "IR",
            "209": "IR", "210": "IR", "211": "IR", "212": "IR",
            "118": "B", "119": "B", "120": "B", "121": "B",
            "185": "B", "186": "B", "187": "B", "188": "B",
            "222": "B", "223": "B", "224": "B", "225": "B",
            "130": "OR", "131": "OR", "132": "OR", "133": "OR",
            "197": "OR", "198": "OR", "199": "OR", "200": "OR",
            "234": "OR", "235": "OR", "236": "OR", "237": "OR"}
res = []
for fnum, cond in cwru_cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath):
        continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys:
        continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w * 12000:(w + 1) * 12000]
        if len(seg) < 12000:
            break
        feats = bhd.analyze(seg, 12000)
        if feats:
            feats["condition"] = cond
            res.append(feats)
all_results["CWRU"] = ("N", res)
print(f"{len(res)} windows")

# --- Paderborn ---
print("Loading Paderborn...", end=" ")
pb_dir = os.path.join(HERE, "..", "data", "paderborn")
pb_map = {"K001": "H", "K002": "H", "KA01": "OR", "KA04": "OR",
          "KI01": "IR", "KI04": "IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath):
        bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath):
        continue
    files = sorted([f for f in os.listdir(bpath)
                    if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0, 0]["Y"][0, 6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w * 16000:(w + 1) * 16000]
            if len(seg) < 16000:
                break
            feats = bhd.analyze(seg, 16000)
            if feats:
                feats["condition"] = cond
                feats["bearing"] = bearing
                res.append(feats)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)} windows")

# --- UOttawa ---
print("Loading UOttawa...", end=" ")
uo_dir = os.path.join(HERE, "..", "..", "data", "uottawa_mendeley")
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"):
            continue
        cc = fname[0]
        if cc not in "HOIBC":
            continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"):
                continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    feats = bhd.analyze(data[:20000], 20000)
                    if feats:
                        feats["condition"] = cond
                        res.append(feats)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)} windows")

# --- JNU ---
print("Loading JNU...", end=" ")
jnu_dir = os.path.join(HERE, "..", "data", "jnu")
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"):
            continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1:
                data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data) // 50000)):
                seg = data[w * 50000:(w + 1) * 50000]
                feats = bhd.analyze(seg, 50000)
                if feats:
                    feats["condition"] = cond
                    res.append(feats)
        except Exception:
            pass
all_results["JNU"] = ("H", res)
print(f"{len(res)} windows")

# --- MFPT ---
print("Loading MFPT...", end=" ")
mfpt_dir = os.path.join(HERE, "..", "data", "mfpt")
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath):
            continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"):
                continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0, 0]["gs"].flatten()
                sr = int(d["bearing"][0, 0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs) // sr)):
                    seg = gs[w * sr:(w + 1) * sr]
                    feats = bhd.analyze(seg, sr)
                    if feats:
                        feats["condition"] = cond
                        res.append(feats)
            except Exception:
                pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)} windows")

# --- MCC5-THU (1000 RPM subset, matches Table 5 "MCC5 (1000)") ---
print("Loading MCC5-THU 1000 RPM...", end=" ")
gear_dir = (r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD"
            r"\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU"
            r"\MCC5-THU gearbox fault diagnosis datasets")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        if "speed_circulation_10Nm-1000rpm" not in fname:
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            feats = bhd.analyze(sig[:20480], 20480)
            if feats:
                feats["condition"] = cond
                res.append(feats)
        except Exception:
            pass
all_results["MCC5 (1000)"] = ("H", res)
print(f"{len(res)} windows")

# --- MCC5-THU all speeds (matches Table 5 "MCC5 (all)") ---
print("Loading MCC5-THU all speeds...", end=" ")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            feats = bhd.analyze(sig[:20480], 20480)
            if feats:
                feats["condition"] = cond
                res.append(feats)
        except Exception:
            pass
all_results["MCC5 (all)"] = ("H", res)
print(f"{len(res)} windows")


# ------------------------------------------------------------------
#  Compute within-window and across-measurement intervals
# ------------------------------------------------------------------
def summarise(class_records):
    """Return dict of sigma statistics for one class."""
    sig_vals = np.array([r["sigma_bayes"] for r in class_records], dtype=float)
    ci_lo = np.array([r["sigma_bayes_ci_low"] for r in class_records], dtype=float)
    ci_hi = np.array([r["sigma_bayes_ci_high"] for r in class_records], dtype=float)
    return {
        "n": int(sig_vals.size),
        "mean": float(np.mean(sig_vals)),
        "std": float(np.std(sig_vals, ddof=1)) if sig_vals.size > 1 else 0.0,
        # mean of per-window within-window CIs (what the old table reported)
        "within_ci_lo": float(np.mean(ci_lo)) if ci_lo.size else float("nan"),
        "within_ci_hi": float(np.mean(ci_hi)) if ci_hi.size else float("nan"),
        # empirical across-measurement 95% CI
        "across_q025": float(np.quantile(sig_vals, 0.025)) if sig_vals.size else float("nan"),
        "across_q975": float(np.quantile(sig_vals, 0.975)) if sig_vals.size else float("nan"),
        # 68% band for plotting
        "across_q16": float(np.quantile(sig_vals, 0.16)) if sig_vals.size else float("nan"),
        "across_q84": float(np.quantile(sig_vals, 0.84)) if sig_vals.size else float("nan"),
        "sigma_values": sig_vals.tolist(),
    }


summary = {}
for name, (healthy_cond, recs) in all_results.items():
    h = [r for r in recs if r["condition"] == healthy_cond]
    f = [r for r in recs if r["condition"] != healthy_cond]
    if not h or not f:
        continue
    summary[name] = {
        "healthy": summarise(h),
        "faulty": summarise(f),
    }

# overlap check (across-measurement)
for name, pack in summary.items():
    h = pack["healthy"]
    f = pack["faulty"]
    within_overlap = not (h["within_ci_hi"] < f["within_ci_lo"]
                          or f["within_ci_hi"] < h["within_ci_lo"])
    across_overlap = not (h["across_q975"] < f["across_q025"]
                          or f["across_q975"] < h["across_q025"])
    pack["within_overlap"] = within_overlap
    pack["across_overlap"] = across_overlap

# ------------------------------------------------------------------
#  Print summary and LaTeX rows
# ------------------------------------------------------------------
print("\n" + "=" * 100)
print("  EMPIRICAL CI SUMMARY (across-measurement 2.5% and 97.5% quantiles)")
print("=" * 100)
print(f"{'Dataset':<14}{'H sigma':>10}{'H 95% CI (across)':>22}"
      f"{'F sigma':>10}{'F 95% CI (across)':>22}  ovlp")
for name, pack in summary.items():
    h = pack["healthy"]
    f = pack["faulty"]
    ov = "YES" if pack["across_overlap"] else "no"
    print(f"{name:<14}"
          f"{h['mean']:>10.4f}"
          f"  [{h['across_q025']:.4f}, {h['across_q975']:.4f}]"
          f"{f['mean']:>10.4f}"
          f"  [{f['across_q025']:.4f}, {f['across_q975']:.4f}]"
          f"  {ov}")

print("\n" + "=" * 100)
print("  COMPARISON: within-window vs across-measurement width (relative to healthy mean)")
print("=" * 100)
print(f"{'Dataset':<14}{'H within w':>14}{'H across w':>14}"
      f"{'F within w':>14}{'F across w':>14}")
for name, pack in summary.items():
    h = pack["healthy"]
    f = pack["faulty"]
    hw = h["within_ci_hi"] - h["within_ci_lo"]
    ha = h["across_q975"] - h["across_q025"]
    fw = f["within_ci_hi"] - f["within_ci_lo"]
    fa = f["across_q975"] - f["across_q025"]
    scale = max(h["mean"], 1e-12)
    print(f"{name:<14}"
          f"{hw / scale:>14.4f}"
          f"{ha / scale:>14.4f}"
          f"{fw / scale:>14.4f}"
          f"{fa / scale:>14.4f}")

# LaTeX table rows
print("\n" + "=" * 100)
print("  LaTeX rows for revised Table 5 (across-measurement 95% intervals)")
print("=" * 100)
latex_lines = []
table_order = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT",
               "MCC5 (1000)", "MCC5 (all)"]
for name in table_order:
    if name not in summary:
        continue
    h = summary[name]["healthy"]
    f = summary[name]["faulty"]
    ov = "No" if not summary[name]["across_overlap"] else "Yes"
    row = (f"{name} & "
           f"{h['mean']:.3f} [{h['across_q025']:.3f}, {h['across_q975']:.3f}] & "
           f"{f['mean']:.3f} [{f['across_q025']:.3f}, {f['across_q975']:.3f}] & "
           f"{ov} \\\\")
    print(" ", row)
    latex_lines.append(row)

# save summary to json and txt
out_json = os.path.join(HERE, "empirical_ci_results.json")
# don't dump full sigma arrays into summary text, but keep them in json
with open(out_json, "w") as fh:
    json.dump(summary, fh, indent=2)
print(f"\n  Saved JSON: {out_json}")

out_txt = os.path.join(HERE, "empirical_ci_results.txt")
with open(out_txt, "w") as fh:
    fh.write("Empirical CI summary (across-measurement 2.5% and 97.5% quantiles)\n")
    fh.write("=" * 90 + "\n")
    for name, pack in summary.items():
        h = pack["healthy"]
        f = pack["faulty"]
        fh.write(f"\n{name}:\n")
        fh.write(f"  Healthy (n={h['n']}): mean={h['mean']:.4f}, "
                 f"std={h['std']:.4f}, "
                 f"within 95% CI=[{h['within_ci_lo']:.4f}, "
                 f"{h['within_ci_hi']:.4f}], "
                 f"across 95% CI=[{h['across_q025']:.4f}, "
                 f"{h['across_q975']:.4f}]\n")
        fh.write(f"  Faulty  (n={f['n']}): mean={f['mean']:.4f}, "
                 f"std={f['std']:.4f}, "
                 f"within 95% CI=[{f['within_ci_lo']:.4f}, "
                 f"{f['within_ci_hi']:.4f}], "
                 f"across 95% CI=[{f['across_q025']:.4f}, "
                 f"{f['across_q975']:.4f}]\n")
        fh.write(f"  Overlap (within): {pack['within_overlap']}, "
                 f"(across): {pack['across_overlap']}\n")
    fh.write("\nLaTeX Table 5 rows:\n")
    for row in latex_lines:
        fh.write("  " + row + "\n")
print(f"  Saved text: {out_txt}")


# ------------------------------------------------------------------
#  Figure: two-panel within-window vs across-measurement
# ------------------------------------------------------------------
print("\nGenerating revised fig_uncertainty_ci.pdf...")

fig, (axL, axR) = plt.subplots(1, 2, figsize=(12, 4.8), sharey=True)

ds_names = list(summary.keys())
y_pos = np.arange(len(ds_names))

for i, name in enumerate(ds_names):
    h = summary[name]["healthy"]
    f = summary[name]["faulty"]
    # Normalise by healthy mean so scales are comparable
    norm = h["mean"] if h["mean"] > 0 else 1.0

    # --- Left panel: within-window CIs ---
    hw_lo, hw_hi = h["within_ci_lo"] / norm, h["within_ci_hi"] / norm
    fw_lo, fw_hi = f["within_ci_lo"] / norm, f["within_ci_hi"] / norm
    axL.barh(i + 0.18, hw_hi - hw_lo, left=hw_lo, height=0.3,
             color="#4CAF50", alpha=0.85, edgecolor="#2E7D32")
    axL.plot(h["mean"] / norm, i + 0.18, "o", color="#1B5E20",
             markersize=7, zorder=5)
    axL.barh(i - 0.18, fw_hi - fw_lo, left=fw_lo, height=0.3,
             color="#F44336", alpha=0.85, edgecolor="#C62828")
    axL.plot(f["mean"] / norm, i - 0.18, "o", color="#B71C1C",
             markersize=7, zorder=5)

    # --- Right panel: across-measurement empirical quantiles ---
    ha_lo, ha_hi = h["across_q025"] / norm, h["across_q975"] / norm
    fa_lo, fa_hi = f["across_q025"] / norm, f["across_q975"] / norm
    axR.barh(i + 0.18, ha_hi - ha_lo, left=ha_lo, height=0.3,
             color="#4CAF50", alpha=0.5, edgecolor="#2E7D32")
    # inner 68% band
    axR.barh(i + 0.18, h["across_q84"] / norm - h["across_q16"] / norm,
             left=h["across_q16"] / norm, height=0.3,
             color="#4CAF50", alpha=0.9, edgecolor="none")
    axR.plot(h["mean"] / norm, i + 0.18, "o", color="#1B5E20",
             markersize=7, zorder=5)
    axR.barh(i - 0.18, fa_hi - fa_lo, left=fa_lo, height=0.3,
             color="#F44336", alpha=0.5, edgecolor="#C62828")
    axR.barh(i - 0.18, f["across_q84"] / norm - f["across_q16"] / norm,
             left=f["across_q16"] / norm, height=0.3,
             color="#F44336", alpha=0.9, edgecolor="none")
    axR.plot(f["mean"] / norm, i - 0.18, "o", color="#B71C1C",
             markersize=7, zorder=5)

for ax, title in [(axL, "(a) Within-window Inv-Gamma 95% CI"),
                  (axR, "(b) Across-measurement empirical 95% interval")]:
    ax.set_yticks(y_pos)
    ax.set_yticklabels(ds_names)
    ax.set_xlabel(r"$\sigma / \sigma_{\mathrm{healthy\,mean}}$")
    ax.set_title(title)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_xlim(0, None)

from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor="#4CAF50", alpha=0.9, edgecolor="#2E7D32",
          label="Healthy"),
    Patch(facecolor="#F44336", alpha=0.9, edgecolor="#C62828",
          label="Faulty"),
]
axR.legend(handles=legend_elements, loc="lower right")

plt.tight_layout()
out_pdf = os.path.join(fig_dir, "fig_uncertainty_ci.pdf")
out_png = os.path.join(fig_dir, "fig_uncertainty_ci.png")
plt.savefig(out_pdf, bbox_inches="tight")
plt.savefig(out_png, dpi=300, bbox_inches="tight")
plt.close()
print(f"  Saved: {out_pdf}")
print(f"  Saved: {out_png}")

print("\nDone.")
