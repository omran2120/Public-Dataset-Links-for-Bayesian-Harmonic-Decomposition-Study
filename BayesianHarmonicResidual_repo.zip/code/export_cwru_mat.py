"""
Rebuild cwru_results.mat with the BAYESIAN numbers, in the exact field layout
plot_cwru_paper.m expects, so the old-style MATLAB figures can be regenerated
with current numbers. Saves to ../cwru_results.mat (old one backed up).
"""
import numpy as np, scipy.io as sio, os, sys
import scipy.signal as sps
from scipy.stats import kurtosis as spk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

DATA = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\cwru"
OUT  = os.path.join(HERE, "..", "cwru_results.mat")

GROUPS = [  # (ftype, severity_mils, files=loads 0..3)
    ("N", 0,  ["97","98","99","100"]),
    ("IR",7,  ["105","106","107","108"]), ("IR",14,["169","170","171","172"]), ("IR",21,["209","210","211","212"]),
    ("B", 7,  ["118","119","120","121"]), ("B",14, ["185","186","187","188"]), ("B",21, ["222","223","224","225"]),
    ("OR",7,  ["130","131","132","133"]), ("OR",14,["197","198","199","200"]), ("OR",21,["234","235","236","237"]),
]

def spectral_kurt(sig, fs):
    f, t, S = sps.stft(sig, fs=fs, nperseg=256, noverlap=192)
    P = np.abs(S)**2
    sk = np.mean(P**2, axis=1) / (np.mean(P, axis=1)**2 + 1e-30) - 2
    return float(np.mean(sk))

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
cols = {k:[] for k in ["condition","fault_size_mils","load_hp","sigma","sigma_norm",
                       "r2","n_freqs","rms","kurtosis","crest_factor",
                       "envelope_kurtosis","spectral_kurtosis_mean"]}
for ftype, sev, files in GROUPS:
    for load, fnum in enumerate(files):
        fp = os.path.join(DATA, f"{fnum}.mat")
        if not os.path.exists(fp): continue
        d = sio.loadmat(fp); keys=[k for k in d if "DE_time" in k]
        if not keys: continue
        data = d[keys[0]].flatten()
        for w in range(4):
            seg = data[w*12000:(w+1)*12000]
            if len(seg) < 12000: break
            ft = bhd.analyze(seg, 12000)
            if not ft: continue
            s0 = seg - np.mean(seg); rms = ft["rms"]
            env = np.abs(sps.hilbert(s0)); env = env - np.mean(env)
            cols["condition"].append(ftype)
            cols["fault_size_mils"].append(sev)
            cols["load_hp"].append(load)
            cols["sigma"].append(ft["sigma_bayes"])
            cols["sigma_norm"].append(ft["sigma_bayes"]/rms if rms>0 else 0.0)
            cols["r2"].append(ft["r2"])
            cols["n_freqs"].append(ft["n_freqs"])
            cols["rms"].append(rms)
            cols["kurtosis"].append(ft["raw_kurtosis"])
            cols["crest_factor"].append(float(np.max(np.abs(s0))/rms) if rms>0 else 0.0)
            cols["envelope_kurtosis"].append(float(spk(env, fisher=True)))
            cols["spectral_kurtosis_mean"].append(spectral_kurt(s0, 12000))

n = len(cols["sigma"]); print(f"{n} CWRU windows")
mat = {"condition": np.array(cols["condition"], dtype=object).reshape(-1,1)}
for k in cols:
    if k == "condition": continue
    mat[k] = np.array(cols[k], dtype=float).reshape(-1,1)
if os.path.exists(OUT):
    os.replace(OUT, OUT.replace(".mat","_aicc_backup.mat"))
sio.savemat(OUT, mat)
# sanity
from bayesian_harmonic_diagnostic import fdr, auc
h=[mat["sigma_norm"][i,0] for i in range(n) if cols["condition"][i]=="N"]
f=[mat["sigma_norm"][i,0] for i in range(n) if cols["condition"][i]!="N"]
print(f"sigma_norm FDR={fdr(h,f):.2f} (target 3.84). Saved {OUT}")
