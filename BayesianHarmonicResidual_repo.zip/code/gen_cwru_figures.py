"""
Regenerate the 6 CWRU diagnostic figures Bayesian-consistently (matching sigma_norm FDR=3.84).
Saves over fig_r2_distribution, fig_sigma_norm_bars, fig_severity_progression,
fig_load_robustness, fig_sigma_vs_kurtosis, fig_feature_heatmap (.pdf) in figures/.
"""
import numpy as np, scipy.io as sio, os, sys
import scipy.signal as sps
from scipy.stats import kurtosis as sp_kurt
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

DATA = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\cwru"
FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
plt.rcParams.update({"font.size": 11, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 120})

# 10 conditions x 4 loads
GROUPS = [
    ("Normal","N", ["97","98","99","100"]),
    ("IR .007","IR",["105","106","107","108"]), ("IR .014","IR",["169","170","171","172"]), ("IR .021","IR",["209","210","211","212"]),
    ("B .007","B", ["118","119","120","121"]), ("B .014","B", ["185","186","187","188"]), ("B .021","B", ["222","223","224","225"]),
    ("OR .007","OR",["130","131","132","133"]), ("OR .014","OR",["197","198","199","200"]), ("OR .021","OR",["234","235","236","237"]),
]
COND_ORDER = [g[0] for g in GROUPS]
FAULT_COLOR = {"N":"#2ca02c","IR":"#d62728","B":"#1f77b4","OR":"#9467bd"}

def baseline_feats(seg):
    seg = seg - np.mean(seg)
    rms = np.sqrt(np.mean(seg**2))
    crest = np.max(np.abs(seg))/rms if rms>0 else 0
    kurt = float(sp_kurt(seg, fisher=True))
    env = np.abs(sps.hilbert(seg)); env = env-np.mean(env)
    env_kurt = float(sp_kurt(env, fisher=True))
    return dict(rms=rms, crest=crest, kurt=kurt, env_kurt=env_kurt)

def load():
    bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
    rows=[]
    for cname, ftype, files in GROUPS:
        for load,fnum in enumerate(files):
            fp=os.path.join(DATA,f"{fnum}.mat")
            if not os.path.exists(fp): continue
            d=sio.loadmat(fp); keys=[k for k in d if "DE_time" in k]
            if not keys: continue
            data=d[keys[0]].flatten()
            for w in range(4):
                seg=data[w*12000:(w+1)*12000]
                if len(seg)<12000: break
                ft=bhd.analyze(seg,12000)
                if not ft: continue
                bf=baseline_feats(seg)
                rows.append(dict(cname=cname, ftype=ftype, load=load,
                    sigma=ft["sigma_bayes"], sigma_norm=ft["sigma_bayes"]/bf["rms"],
                    r2=ft["r2"], **bf))
    return rows

def agg(rows,key,cname):
    v=[r[key] for r in rows if r["cname"]==cname]
    return np.mean(v), np.std(v)

def main():
    rows=load(); print(f"{len(rows)} CWRU windows")
    cmeans={c:{} for c in COND_ORDER}
    for c in COND_ORDER:
        for k in ["sigma","sigma_norm","r2","kurt","env_kurt","crest"]:
            cmeans[c][k]=agg(rows,k,c)
    base = cmeans["Normal"]["sigma_norm"][0]

    # 1) R^2 distribution
    fig,ax=plt.subplots(figsize=(7,3.2))
    m=[cmeans[c]["r2"][0] for c in COND_ORDER]; e=[cmeans[c]["r2"][1] for c in COND_ORDER]
    cols=[FAULT_COLOR[g[1]] for g in GROUPS]
    ax.bar(COND_ORDER,m,yerr=e,color=cols,edgecolor="k",linewidth=0.6,capsize=3)
    ax.set_ylabel(r"Harmonic fit $R^2$"); ax.set_ylim(0,1)
    plt.xticks(rotation=35,ha="right"); plt.tight_layout()
    plt.savefig(os.path.join(FIG,"fig_r2_distribution.pdf")); plt.close()

    # 2) sigma_norm bars
    fig,ax=plt.subplots(figsize=(7,3.2))
    m=[cmeans[c]["sigma_norm"][0] for c in COND_ORDER]; e=[cmeans[c]["sigma_norm"][1] for c in COND_ORDER]
    ax.bar(COND_ORDER,m,yerr=e,color=cols,edgecolor="k",linewidth=0.6,capsize=3)
    ax.axhline(base,ls="--",c="k",lw=1,label="Normal baseline")
    ax.set_ylabel(r"$\sigma_{\mathrm{norm}}$"); ax.legend()
    plt.xticks(rotation=35,ha="right"); plt.tight_layout()
    plt.savefig(os.path.join(FIG,"fig_sigma_norm_bars.pdf")); plt.close()

    # 3) severity progression (3 fault types)
    fig,ax=plt.subplots(figsize=(6,3.4))
    sev=["Normal",".007",".014",".021"]
    for ft,marker in [("IR","o"),("B","s"),("OR","^")]:
        ys=[cmeans["Normal"]["sigma_norm"][0]]+[cmeans[f"{ft} {s}"]["sigma_norm"][0] for s in [".007",".014",".021"]]
        es=[cmeans["Normal"]["sigma_norm"][1]]+[cmeans[f"{ft} {s}"]["sigma_norm"][1] for s in [".007",".014",".021"]]
        ax.errorbar(sev,ys,yerr=es,marker=marker,capsize=3,label=ft,color=FAULT_COLOR[ft],lw=1.5)
    ax.set_xlabel("Fault severity"); ax.set_ylabel(r"$\sigma_{\mathrm{norm}}$"); ax.legend()
    plt.tight_layout(); plt.savefig(os.path.join(FIG,"fig_severity_progression.pdf")); plt.close()

    # 4) load robustness (by fault type, averaged over severities)
    fig,ax=plt.subplots(figsize=(6,3.4))
    for ft in ["N","IR","B","OR"]:
        ys=[]; es=[]
        for L in range(4):
            v=[r["sigma_norm"] for r in rows if r["ftype"]==ft and r["load"]==L]
            ys.append(np.mean(v)); es.append(np.std(v))
        lab={"N":"Normal","IR":"IR","B":"Ball","OR":"OR"}[ft]
        ax.errorbar([0,1,2,3],ys,yerr=es,marker="o",capsize=3,label=lab,color=FAULT_COLOR[ft],lw=1.5)
    ax.set_xlabel("Motor load (HP)"); ax.set_ylabel(r"$\sigma_{\mathrm{norm}}$"); ax.set_xticks([0,1,2,3]); ax.legend(ncol=2)
    plt.tight_layout(); plt.savefig(os.path.join(FIG,"fig_load_robustness.pdf")); plt.close()

    # 5) sigma vs kurtosis scatter
    fig,ax=plt.subplots(figsize=(6,3.6))
    for ft,marker in [("N","o"),("IR","s"),("B","^"),("OR","D")]:
        xs=[r["kurt"] for r in rows if r["ftype"]==ft]; ys=[r["sigma"] for r in rows if r["ftype"]==ft]
        lab={"N":"Normal","IR":"IR","B":"Ball","OR":"OR"}[ft]
        ax.scatter(xs,ys,marker=marker,c=FAULT_COLOR[ft],edgecolor="k",linewidth=0.3,s=34,alpha=0.8,label=lab)
    ax.set_xlabel("Kurtosis"); ax.set_ylabel(r"Harmonic residual $\sigma$"); ax.legend()
    plt.tight_layout(); plt.savefig(os.path.join(FIG,"fig_sigma_vs_kurtosis.pdf")); plt.close()

    # 6) feature heatmap (5 features x 10 conditions, column-normalized)
    feats=["sigma_norm","sigma","kurt","env_kurt","crest"]
    flabels=[r"$\sigma_{\mathrm{norm}}$",r"$\sigma$","Kurtosis","Env. kurt.","Crest"]
    M=np.array([[cmeans[c][f][0] for c in COND_ORDER] for f in feats])
    Mn=(M-M.min(axis=1,keepdims=True))/(M.max(axis=1,keepdims=True)-M.min(axis=1,keepdims=True)+1e-12)
    fig,ax=plt.subplots(figsize=(7,2.8))
    im=ax.imshow(Mn,aspect="auto",cmap="viridis")
    ax.set_yticks(range(len(feats))); ax.set_yticklabels(flabels)
    ax.set_xticks(range(len(COND_ORDER))); ax.set_xticklabels(COND_ORDER,rotation=35,ha="right")
    fig.colorbar(im,ax=ax,label="Normalised response")
    plt.tight_layout(); plt.savefig(os.path.join(FIG,"fig_feature_heatmap.pdf")); plt.close()

    # report
    from bayesian_harmonic_diagnostic import fdr,auc
    h=[r["sigma_norm"] for r in rows if r["ftype"]=="N"]; f=[r["sigma_norm"] for r in rows if r["ftype"]!="N"]
    print(f"check: sigma_norm FDR={fdr(h,f):.2f} AUC={auc(h,f):.3f} (should match paper 3.84)")
    print("Saved 6 CWRU figures.")

if __name__=="__main__": main()
