"""
Generate all figures for the Bayesian Harmonic Diagnostic paper.
Saves to BH_Indicator/figures/
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
import os
from functools import partial
print = partial(print, flush=True)

fig_dir = os.path.join(os.path.dirname(__file__), 'figures')
os.makedirs(fig_dir, exist_ok=True)

# Common style
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 12,
    'axes.labelsize': 16,
    'axes.titlesize': 16,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 300,
})

# ============================================================
# Load all results from the Bayesian run
# We'll recompute quickly here
# ============================================================
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'bayesian_approach'))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic, fdr, auc
import scipy.io as sio
import scipy.signal as sig_proc

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
all_results = {}

# CWRU
print("Loading CWRU...", end=" ")
cwru_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'cwru')
cat = {"97":"N","98":"N","99":"N","100":"N","105":"IR","106":"IR","107":"IR","108":"IR",
       "169":"IR","170":"IR","171":"IR","172":"IR","209":"IR","210":"IR","211":"IR","212":"IR",
       "118":"B","119":"B","120":"B","121":"B","185":"B","186":"B","187":"B","188":"B",
       "222":"B","223":"B","224":"B","225":"B","130":"OR","131":"OR","132":"OR","133":"OR",
       "197":"OR","198":"OR","199":"OR","200":"OR","234":"OR","235":"OR","236":"OR","237":"OR"}
res = []
for fnum, cond in cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath): continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys: continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w*12000:(w+1)*12000]
        if len(seg)<12000: break
        feats = bhd.analyze(seg, 12000)
        if feats: feats["condition"]=cond; res.append(feats)
all_results["CWRU"] = ("N", res)
print(f"{len(res)}")

# Paderborn
print("Loading Paderborn...", end=" ")
pb_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'paderborn')
pb_map = {"K001":"H","K002":"H","KA01":"OR","KA04":"OR","KI01":"IR","KI04":"IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath): bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath): continue
    files = sorted([f for f in os.listdir(bpath) if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0,0]["Y"][0,6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w*16000:(w+1)*16000]
            if len(seg)<16000: break
            feats = bhd.analyze(seg, 16000)
            if feats: feats["condition"]=cond; feats["bearing"]=bearing; res.append(feats)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)}")

# UOttawa
print("Loading UOttawa...", end=" ")
uo_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\data\uottawa_mendeley"
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"): continue
        cc = fname[0]
        if cc not in "HOIBC": continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"): continue
            arr = d[key]
            if hasattr(arr,"shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    feats = bhd.analyze(data[:20000], 20000)
                    if feats: feats["condition"]=cond; feats["fault_type"]=cc; res.append(feats)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)}")

# JNU
print("Loading JNU...", end=" ")
jnu_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'jnu')
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"): continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1: data = data[:,0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data)//50000)):
                seg = data[w*50000:(w+1)*50000]
                feats = bhd.analyze(seg, 50000)
                if feats: feats["condition"]=cond; res.append(feats)
        except: pass
all_results["JNU"] = ("H", res)
print(f"{len(res)}")

# MFPT
print("Loading MFPT...", end=" ")
mfpt_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'mfpt')
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath): continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"): continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0,0]["gs"].flatten()
                sr = int(d["bearing"][0,0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs)//sr)):
                    seg = gs[w*sr:(w+1)*sr]
                    feats = bhd.analyze(seg, sr)
                    if feats: feats["condition"]=cond; res.append(feats)
            except: pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)}")

# MCC5-THU
print("Loading MCC5-THU...", end=" ")
gear_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU\MCC5-THU gearbox fault diagnosis datasets"
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"): continue
        if "speed_circulation_10Nm-1000rpm" not in fname: continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
            sig = data[:, 5]
            feats = bhd.analyze(sig[:20480], 20480)
            if feats: feats["condition"]=cond; res.append(feats)
        except: pass
all_results["MCC5"] = ("H", res)
print(f"{len(res)}")

print("\nGenerating figures...")

# ============================================================
# FIG 2: FDR comparison across all datasets (sigma vs kurtosis)
# ============================================================
print("  Fig 2: FDR comparison across datasets...")
datasets = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]
sigma_fdrs = []
kurt_fdrs = []
for name in datasets:
    hc, results = all_results[name]
    h = [r for r in results if r["condition"]==hc]
    f = [r for r in results if r["condition"]!=hc]
    if h and f:
        sigma_fdrs.append(fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f]))
        kurt_fdrs.append(fdr([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f]))
    else:
        sigma_fdrs.append(0); kurt_fdrs.append(0)

fig, ax = plt.subplots(figsize=(10, 5))
x = np.arange(len(datasets))
w = 0.35
bars1 = ax.bar(x - w/2, sigma_fdrs, w, label=r'$\sigma$ (Bayesian)', color='#2196F3', edgecolor='#1565C0', linewidth=0.8)
bars2 = ax.bar(x + w/2, kurt_fdrs, w, label='Kurtosis (residual)', color='#FF5722', edgecolor='#BF360C', linewidth=0.8)
ax.set_ylabel('Fisher Discriminant Ratio (FDR)', fontsize=16)
ax.set_xticks(x)
ax.set_xticklabels(datasets, fontsize=13)
ax.legend(fontsize=13, loc='upper left')
ax.set_ylim(0, max(max(sigma_fdrs), max(kurt_fdrs)) * 1.15)
# Add winner markers
for i in range(len(datasets)):
    winner_y = max(sigma_fdrs[i], kurt_fdrs[i])
    if sigma_fdrs[i] > kurt_fdrs[i]:
        ratio = sigma_fdrs[i] / kurt_fdrs[i] if kurt_fdrs[i] > 0.01 else 999
        ax.text(i, winner_y + 0.15, f'{ratio:.0f}x', ha='center', fontsize=10, color='#1565C0', fontweight='bold')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'fig_fdr_all_datasets.pdf'), bbox_inches='tight')
plt.savefig(os.path.join(fig_dir, 'fig_fdr_all_datasets.png'), dpi=300, bbox_inches='tight')
plt.close()
print("    Saved: fig_fdr_all_datasets.pdf")

# ============================================================
# FIG 3: Paderborn per-bearing with Bayesian CI
# ============================================================
print("  Fig 3: Paderborn per-bearing with CI...")
hc, pb = all_results["Paderborn"]
bearings = ["K001", "K002", "KA01", "KA04", "KI01", "KI04"]
labels_pb = ["K001\n(Healthy)", "K002\n(Healthy)", "KA01\n(OR artif.)", "KA04\n(OR real)", "KI01\n(IR artif.)", "KI04\n(IR real)"]
sigma_means = []
sigma_ci_low = []
sigma_ci_high = []
kurt_means = []
for b in bearings:
    sub = [r for r in pb if r.get("bearing")==b]
    if sub:
        sigma_means.append(np.mean([r["sigma_bayes"] for r in sub]))
        sigma_ci_low.append(np.mean([r["sigma_bayes_ci_low"] for r in sub]))
        sigma_ci_high.append(np.mean([r["sigma_bayes_ci_high"] for r in sub]))
        kurt_means.append(np.mean([r["resid_kurtosis"] for r in sub]))

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Left: sigma with CI
colors_pb = ['#4CAF50', '#4CAF50', '#2196F3', '#FF9800', '#2196F3', '#FF9800']
x_pb = np.arange(len(bearings))
yerr_low = np.array(sigma_means) - np.array(sigma_ci_low)
yerr_high = np.array(sigma_ci_high) - np.array(sigma_means)
ax1.bar(x_pb, sigma_means, color=colors_pb, edgecolor='black', linewidth=0.5, alpha=0.85)
ax1.errorbar(x_pb, sigma_means, yerr=[yerr_low, yerr_high], fmt='none', ecolor='black', capsize=5, linewidth=1.5)
ax1.axhline(np.mean(sigma_means[:2]), color='green', linestyle='--', alpha=0.5, label='Healthy baseline')
ax1.set_ylabel(r'$\sigma$ (Bayesian posterior)', fontsize=14)
ax1.set_xticks(x_pb)
ax1.set_xticklabels(labels_pb, fontsize=10)
ax1.legend(fontsize=10)
ax1.set_title(r'(a) Posterior $\sigma$ with 95% CI', fontsize=14)
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

# Right: kurtosis
colors_kurt = ['#4CAF50', '#4CAF50', '#F44336', '#F44336', '#F44336', '#F44336']
ax2.bar(x_pb, kurt_means, color=colors_kurt, edgecolor='black', linewidth=0.5, alpha=0.85)
ax2.axhline(np.mean(kurt_means[:2]), color='green', linestyle='--', alpha=0.5, label='Healthy baseline')
# Highlight failures
for i in [3, 5]:  # KA04, KI04
    ax2.annotate('BELOW\nhealthy', xy=(i, kurt_means[i]), xytext=(i, kurt_means[i]+2),
                ha='center', fontsize=9, color='red', fontweight='bold',
                arrowprops=dict(arrowstyle='->', color='red'))
ax2.set_ylabel('Kurtosis (residual)', fontsize=14)
ax2.set_xticks(x_pb)
ax2.set_xticklabels(labels_pb, fontsize=10)
ax2.legend(fontsize=10)
ax2.set_title('(b) Residual kurtosis', fontsize=14)
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'fig_paderborn_comparison.pdf'), bbox_inches='tight')
plt.savefig(os.path.join(fig_dir, 'fig_paderborn_comparison.png'), dpi=300, bbox_inches='tight')
plt.close()
print("    Saved: fig_paderborn_comparison.pdf")

# ============================================================
# FIG 4: Uncertainty visualization (CI overlap)
# ============================================================
print("  Fig 4: Uncertainty CI overlap...")
fig, ax = plt.subplots(figsize=(10, 5))

ds_names = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]
y_pos = np.arange(len(ds_names))

for i, name in enumerate(ds_names):
    hc, results = all_results[name]
    h = [r for r in results if r["condition"]==hc]
    f = [r for r in results if r["condition"]!=hc]
    if not h or not f: continue

    h_mean = np.mean([r["sigma_bayes"] for r in h])
    h_lo = np.mean([r["sigma_bayes_ci_low"] for r in h])
    h_hi = np.mean([r["sigma_bayes_ci_high"] for r in h])
    f_mean = np.mean([r["sigma_bayes"] for r in f])
    f_lo = np.mean([r["sigma_bayes_ci_low"] for r in f])
    f_hi = np.mean([r["sigma_bayes_ci_high"] for r in f])

    # Normalize for visualization (divide by healthy mean)
    norm = h_mean
    ax.barh(i + 0.18, (h_hi-h_lo)/norm, left=h_lo/norm, height=0.3, color='#4CAF50', alpha=0.7, edgecolor='#2E7D32')
    ax.plot(h_mean/norm, i + 0.18, 'o', color='#2E7D32', markersize=8, zorder=5)
    ax.barh(i - 0.18, (f_hi-f_lo)/norm, left=f_lo/norm, height=0.3, color='#F44336', alpha=0.7, edgecolor='#C62828')
    ax.plot(f_mean/norm, i - 0.18, 'o', color='#C62828', markersize=8, zorder=5)

ax.set_yticks(y_pos)
ax.set_yticklabels(ds_names, fontsize=13)
ax.set_xlabel(r'$\sigma / \sigma_{\mathrm{healthy}}$ (normalized)', fontsize=14)
ax.legend(['Healthy', '', 'Faulty', ''], fontsize=11, loc='upper right')
# Custom legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor='#4CAF50', alpha=0.7, edgecolor='#2E7D32', label='Healthy 95% CI'),
                   Patch(facecolor='#F44336', alpha=0.7, edgecolor='#C62828', label='Faulty 95% CI')]
ax.legend(handles=legend_elements, fontsize=12, loc='lower right')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.set_xlim(0, None)
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'fig_uncertainty_ci.pdf'), bbox_inches='tight')
plt.savefig(os.path.join(fig_dir, 'fig_uncertainty_ci.png'), dpi=300, bbox_inches='tight')
plt.close()
print("    Saved: fig_uncertainty_ci.pdf")

# ============================================================
# FIG 5: Gear data - our method vs Yin's
# ============================================================
print("  Fig 5: Gear comparison...")
# Use MCC5 results
hc, gear = all_results["MCC5"]
h_gear = [r for r in gear if r["condition"]=="H"]
f_gear = [r for r in gear if r["condition"]!="H"]

if h_gear and f_gear:
    methods = ['Ours:\nBayesian + σ', "Yin's:\nTSA + kurt.", 'Ours:\nBayesian + kurt.']
    # Values from our comparison run
    fdrs_gear = [1.990, 0.119, 0.042]
    colors_gear = ['#2196F3', '#FF5722', '#FF5722']

    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(range(len(methods)), fdrs_gear, color=colors_gear, edgecolor='black', linewidth=0.5, alpha=0.85)
    bars[0].set_edgecolor('#1565C0')
    ax.set_ylabel('Fisher Discriminant Ratio (FDR)', fontsize=14)
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, fontsize=12)
    ax.set_title('MCC5-THU Gear Data (1000 RPM)', fontsize=14)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, 'fig_gear_comparison.pdf'), bbox_inches='tight')
    plt.savefig(os.path.join(fig_dir, 'fig_gear_comparison.png'), dpi=300, bbox_inches='tight')
    plt.close()
    print("    Saved: fig_gear_comparison.pdf")

# ============================================================
# FIG 6: Score card - wins per dataset
# ============================================================
print("  Fig 6: Score card...")
fig, ax = plt.subplots(figsize=(8, 4))

ds_all = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]
sigma_wins = []
for name in ds_all:
    hc, results = all_results[name]
    h = [r for r in results if r["condition"]==hc]
    f = [r for r in results if r["condition"]!=hc]
    if h and f:
        sf = fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
        kf = fdr([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
        sigma_wins.append(1 if sf > kf else 0)
    else:
        sigma_wins.append(0)

colors_sc = ['#2196F3' if w else '#FF5722' for w in sigma_wins]
labels_sc = [r'$\sigma$ wins' if w else 'Kurt. wins' for w in sigma_wins]

ax.barh(range(len(ds_all)), [1]*len(ds_all), color=colors_sc, edgecolor='black', linewidth=0.5, alpha=0.85)
for i, (name, label) in enumerate(zip(ds_all, labels_sc)):
    ax.text(0.5, i, f"{name}: {label}", ha='center', va='center', fontsize=13, fontweight='bold', color='white')

ax.set_xlim(0, 1)
ax.set_yticks([])
ax.set_xticks([])
ax.set_title(f'Score Card: Bayesian $\\sigma$ wins {sum(sigma_wins)}/{len(ds_all)} datasets', fontsize=14)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'fig_scorecard.pdf'), bbox_inches='tight')
plt.savefig(os.path.join(fig_dir, 'fig_scorecard.png'), dpi=300, bbox_inches='tight')
plt.close()
print("    Saved: fig_scorecard.pdf")

print("\nAll figures generated!")
