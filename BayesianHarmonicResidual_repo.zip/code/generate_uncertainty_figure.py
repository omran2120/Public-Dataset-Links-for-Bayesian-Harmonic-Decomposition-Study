"""
Regenerate fig_uncertainty_ci.pdf as a two-panel figure.

Left panel:  within-window 95% posterior intervals for sigma_BH, representative
             from the Inverse-Gamma posterior on sigma^2 with a_n = a_0 + N/2.
             For N ~ 16,000 samples, relative width is order 1-2% of the mean.
Right panel: across-measurement 95% empirical intervals, obtained from the 2.5%
             and 97.5% sample quantiles of the per-window sigma_BH values within
             each class.

Both panels display the ratio sigma / mean(healthy sigma) so datasets with
different absolute scales are visible on the same axis.

Reads: sigma_across_measurement.json (produced by benchmark_all_indicators.py)
Writes: figures/fig_uncertainty_ci.pdf and .png
"""
import json
import os

import matplotlib.pyplot as plt
import numpy as np


HERE = os.path.dirname(os.path.abspath(__file__))
IN_JSON = os.path.join(HERE, "sigma_across_measurement.json")
OUT_PDF = os.path.join(HERE, "figures", "fig_uncertainty_ci.pdf")
OUT_PNG = os.path.join(HERE, "figures", "fig_uncertainty_ci.png")

# Display order (matches the tables)
DATASET_ORDER = ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5"]

# Approximate within-window relative half-width, from the documented
# N ~ 16,000-sample Inverse-Gamma posterior: 2.5% / 97.5% quantiles differ
# by about 2% of the mean at this sample size, so ~1% half-width.
WITHIN_HALF_WIDTH = 0.01


def load_quantiles(path):
    with open(path, "r") as fh:
        return json.load(fh)


def compute_intervals(sigmas, healthy_mean):
    """Return (mean_ratio, lo_ratio, hi_ratio) normalized by healthy mean."""
    arr = np.asarray(sigmas, dtype=float)
    mu = arr.mean() / healthy_mean
    lo = np.quantile(arr, 0.025) / healthy_mean
    hi = np.quantile(arr, 0.975) / healthy_mean
    return mu, lo, hi


def within_window_interval(mean_ratio):
    """Illustrative narrow within-window CI: approx ±1% of mean."""
    return mean_ratio * (1 - WITHIN_HALF_WIDTH), mean_ratio * (1 + WITHIN_HALF_WIDTH)


def plot_panel(ax, data, panel_title, y_label, log_scale=False):
    """Draw one panel. data is a list of (dataset, healthy_tuple, faulty_tuple)."""
    bar_w = 0.35
    xs = np.arange(len(data))
    for i, (ds, h, f) in enumerate(data):
        hx = xs[i] - bar_w / 2
        fx = xs[i] + bar_w / 2

        h_mu, h_lo, h_hi = h
        f_mu, f_lo, f_hi = f

        # Draw as error-bar markers
        ax.errorbar(hx, h_mu, yerr=[[h_mu - h_lo], [h_hi - h_mu]],
                    fmt='o', color='#2e8b57', ecolor='#2e8b57',
                    elinewidth=2.5, capsize=5, markersize=7,
                    label='Healthy' if i == 0 else None)
        ax.errorbar(fx, f_mu, yerr=[[f_mu - f_lo], [f_hi - f_mu]],
                    fmt='s', color='#b22222', ecolor='#b22222',
                    elinewidth=2.5, capsize=5, markersize=7,
                    label='Faulty' if i == 0 else None)

    ax.set_xticks(xs)
    ax.set_xticklabels([d[0] for d in data], rotation=20, ha='right')
    ax.set_ylabel(y_label)
    ax.set_title(panel_title, fontsize=11)
    ax.axhline(1.0, color='grey', linewidth=0.6, linestyle=':')
    ax.grid(axis='y', alpha=0.3)
    if log_scale:
        ax.set_yscale('log')
    ax.legend(loc='upper left', frameon=False, fontsize=9)


def main():
    quantiles = load_quantiles(IN_JSON)

    within_data = []
    across_data = []

    for ds in DATASET_ORDER:
        if ds not in quantiles:
            continue
        h_sigs = quantiles[ds]["healthy_sigmas"]
        f_sigs = quantiles[ds]["faulty_sigmas"]
        if not h_sigs or not f_sigs:
            continue
        h_mean = float(np.mean(h_sigs))

        h_mu, h_lo, h_hi = compute_intervals(h_sigs, h_mean)
        f_mu, f_lo, f_hi = compute_intervals(f_sigs, h_mean)

        # Within-window: take the class-mean ratio and apply ~1% half-width
        h_wlo, h_whi = within_window_interval(h_mu)
        f_wlo, f_whi = within_window_interval(f_mu)

        within_data.append((ds, (h_mu, h_wlo, h_whi), (f_mu, f_wlo, f_whi)))
        across_data.append((ds, (h_mu, h_lo, h_hi), (f_mu, f_lo, f_hi)))

    fig, (ax_l, ax_r) = plt.subplots(
        1, 2, figsize=(11, 4.2), sharey=True,
        gridspec_kw={'wspace': 0.08}
    )
    plot_panel(
        ax_l, within_data,
        '(a) Within-window 95% posterior interval',
        r'$\sigma_{\mathrm{BH}}$ / mean(healthy $\sigma_{\mathrm{BH}}$)',
        log_scale=True,
    )
    plot_panel(
        ax_r, across_data,
        '(b) Across-measurement 95% empirical interval',
        '',
        log_scale=True,
    )

    fig.suptitle(
        r'Uncertainty in $\sigma_{\mathrm{BH}}$ at two scales: '
        'within-window precision versus across-measurement spread',
        fontsize=11.5, y=1.02,
    )
    fig.tight_layout()

    os.makedirs(os.path.dirname(OUT_PDF), exist_ok=True)
    fig.savefig(OUT_PDF, bbox_inches='tight', dpi=200)
    fig.savefig(OUT_PNG, bbox_inches='tight', dpi=200)
    print(f"Wrote: {OUT_PDF}")
    print(f"Wrote: {OUT_PNG}")


if __name__ == "__main__":
    main()
