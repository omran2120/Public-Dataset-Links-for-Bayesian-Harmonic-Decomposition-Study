"""
Lambda sensitivity analysis for the Bayesian Harmonic Residual σ_BH
(Priority 7 of the revision plan).

Sweeps the prior precision λ over {0.01, 0.1, 1.0, 10.0, 100.0} on two
representative datasets:
  - Paderborn  (constant-load, real fatigue damage)
  - MCC5-THU   (distributed gear faults at 1000 RPM)

For each λ, reports:
  - healthy mean σ_BH and faulty mean σ_BH
  - FDR and AUC between healthy and faulty classes
  - mean log marginal likelihood across all windows

Additionally runs per-window marginal-likelihood model selection via
BayesianHarmonicDiagnostic.automatic_model_selection, which picks the λ
that maximises ln p(x | M) on each window, and compares the resulting
FDR against the fixed λ = 1.0 setting used in the main paper.

Emits:
  - stdout table and LaTeX rows for tab:lambda_sensitivity
  - lambda_sensitivity.json with the full per-window record
"""
import os
import sys
import json
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
from functools import partial

print = partial(print, flush=True)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic


LAMBDA_GRID = [0.01, 0.1, 1.0, 10.0, 100.0]
FIXED_LAMBDA = 1.0


def fdr(h, f):
    mu_h, s_h = np.mean(h), np.std(h)
    mu_f, s_f = np.mean(f), np.std(f)
    d = s_h ** 2 + s_f ** 2
    return (mu_h - mu_f) ** 2 / d if d > 1e-20 else 0.0


def auc_metric(h, f):
    labels = np.array([0] * len(h) + [1] * len(f))
    scores = np.array(list(h) + list(f))
    thr = np.sort(np.unique(scores))
    tpr_a, fpr_a = [], []
    for t in thr:
        tpr_a.append(np.sum(scores[labels == 1] >= t) / np.sum(labels == 1))
        fpr_a.append(np.sum(scores[labels == 0] >= t) / np.sum(labels == 0))
    o = np.argsort(fpr_a)
    return float(np.trapezoid(np.array(tpr_a)[o], np.array(fpr_a)[o]))


def analyze_window(bhd, sig, fs, lam):
    """Run the diagnostic at a specified λ, return dict with σ_bayes and lnML."""
    bhd.lam = lam
    out = bhd.analyze(sig, fs)
    if out is None:
        return None
    return {
        "sigma_bayes": out["sigma_bayes"],
        "log_marginal": out.get("log_marginal", float("nan")),
        "r2": out.get("r2", float("nan")),
    }


def load_paderborn_windows():
    """Yield (condition, segment, fs) for Paderborn primary subset."""
    pb_dir = os.path.join(os.path.dirname(__file__), "..", "data", "paderborn")
    pb_map = {"K001": "H", "K002": "H", "KA01": "F", "KA04": "F", "KI01": "F", "KI04": "F"}
    for bearing, cond in pb_map.items():
        bpath = os.path.join(pb_dir, bearing, bearing)
        if not os.path.exists(bpath):
            bpath = os.path.join(pb_dir, bearing)
        if not os.path.exists(bpath):
            continue
        files = sorted(
            f for f in os.listdir(bpath)
            if f.startswith("N15_M07_F10") and f.endswith(".mat")
        )[:5]
        for fname in files:
            d = sio.loadmat(os.path.join(bpath, fname))
            key = [k for k in d.keys() if not k.startswith("_")][0]
            raw = d[key][0, 0]["Y"][0, 6]["Data"].flatten()
            data = sig_proc.decimate(raw, 4)
            for w in range(3):
                seg = data[w * 16000:(w + 1) * 16000]
                if len(seg) < 16000:
                    break
                yield cond, seg, 16000.0


def load_mcc5_windows():
    """Yield (condition, segment, fs) for MCC5-THU primary subset (1000 RPM)."""
    gear_dir = (
        r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD"
        r"\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU"
        r"\MCC5-THU gearbox fault diagnosis datasets"
    )
    if not os.path.exists(gear_dir):
        return
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        if "speed_circulation_10Nm-1000rpm" not in fname:
            continue
        cond = "H" if fname.startswith("health") else "F"
        data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
        seg = data[:20480, 5]
        if len(seg) < 20480:
            continue
        yield cond, seg, 20480.0


def sweep(bhd, windows, label):
    """Run the λ sweep across a list of cached windows."""
    cached = list(windows)
    n = len(cached)
    print(f"\n  {label}: {n} windows cached.")

    results = {}
    for lam in LAMBDA_GRID:
        h_sigs, f_sigs, lmls = [], [], []
        for cond, seg, fs in cached:
            r = analyze_window(bhd, seg, fs, lam)
            if r is None:
                continue
            if cond == "H":
                h_sigs.append(r["sigma_bayes"])
            else:
                f_sigs.append(r["sigma_bayes"])
            lmls.append(r["log_marginal"])

        fd = fdr(h_sigs, f_sigs) if h_sigs and f_sigs else float("nan")
        au = auc_metric(h_sigs, f_sigs) if h_sigs and f_sigs else float("nan")
        results[lam] = {
            "h_mean": float(np.mean(h_sigs)) if h_sigs else float("nan"),
            "f_mean": float(np.mean(f_sigs)) if f_sigs else float("nan"),
            "fdr": float(fd),
            "auc": float(au),
            "mean_lnML": float(np.mean(lmls)) if lmls else float("nan"),
            "n_healthy": len(h_sigs),
            "n_faulty": len(f_sigs),
        }
        print(
            f"    λ={lam:>7.2f}   σ_H={results[lam]['h_mean']:.4f}   "
            f"σ_F={results[lam]['f_mean']:.4f}   FDR={fd:.3f}   "
            f"AUC={au:.3f}   ⟨lnML⟩={results[lam]['mean_lnML']:.1f}"
        )

    # Per-window marginal-likelihood optimum
    print(f"  {label}: per-window marginal-likelihood optimum λ*")
    best_lambdas = []
    h_sigs_opt, f_sigs_opt = [], []
    for cond, seg, fs in cached:
        out = bhd.automatic_model_selection(seg, fs, lambda_values=LAMBDA_GRID)
        if out is None:
            continue
        best_lambdas.append(out["best_lambda"])
        if cond == "H":
            h_sigs_opt.append(out["sigma_bayes"])
        else:
            f_sigs_opt.append(out["sigma_bayes"])

    fd_opt = fdr(h_sigs_opt, f_sigs_opt) if h_sigs_opt and f_sigs_opt else float("nan")
    au_opt = auc_metric(h_sigs_opt, f_sigs_opt) if h_sigs_opt and f_sigs_opt else float("nan")
    median_lambda = float(np.median(best_lambdas)) if best_lambdas else float("nan")
    mode_lambda = (
        max(set(best_lambdas), key=best_lambdas.count) if best_lambdas else float("nan")
    )
    print(
        f"    per-window median λ*={median_lambda:.2f}, mode λ*={mode_lambda:.2f}, "
        f"FDR={fd_opt:.3f}, AUC={au_opt:.3f}"
    )

    results["per_window_ml"] = {
        "median_lambda": median_lambda,
        "mode_lambda": mode_lambda,
        "fdr": float(fd_opt),
        "auc": float(au_opt),
        "n_healthy": len(h_sigs_opt),
        "n_faulty": len(f_sigs_opt),
    }
    bhd.lam = FIXED_LAMBDA
    return results


if __name__ == "__main__":
    bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=FIXED_LAMBDA)

    print("=" * 80)
    print("  LAMBDA SENSITIVITY ANALYSIS — Priority 7")
    print("=" * 80)

    all_sens = {}
    all_sens["Paderborn"] = sweep(bhd, load_paderborn_windows(), "Paderborn")
    all_sens["MCC5"] = sweep(bhd, load_mcc5_windows(), "MCC5-THU (1000 RPM)")

    out = os.path.join(os.path.dirname(__file__), "lambda_sensitivity.json")
    with open(out, "w") as fh:
        json.dump(all_sens, fh, indent=2, default=str)
    print(f"\n  Wrote: {out}")

    # LaTeX rows for tab:lambda_sensitivity
    print("\n  LaTeX rows for tab:lambda_sensitivity:")
    for ds, label in [("Paderborn", "Paderborn"), ("MCC5", "MCC5-THU")]:
        if ds not in all_sens:
            continue
        for lam in LAMBDA_GRID:
            r = all_sens[ds].get(lam)
            if r is None:
                continue
            print(
                f"    {label} & {lam} & {r['h_mean']:.3f} & "
                f"{r['f_mean']:.3f} & {r['fdr']:.3f} & "
                f"{r['auc']:.3f} \\\\"
            )
        r = all_sens[ds].get("per_window_ml")
        if r is not None:
            print(
                f"    {label} & ln\\,ML opt & --- & --- & "
                f"{r['fdr']:.3f} & {r['auc']:.3f} \\\\   "
                f"% median λ*={all_sens[ds]['per_window_ml']['median_lambda']}"
            )

    print("\nDone!")
