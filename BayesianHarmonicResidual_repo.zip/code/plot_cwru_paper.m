%% Publication Figures — CWRU Bearing Fault Analysis
%  Generates 6 publication-quality figures for SHM journal
%  Input:  cwru_results.mat
%  Output: figures/*.pdf (vector)
%
%  Omrane Abdallah, University of Manitoba, 2026

clear; clc; close all;

%% Load data
data = load(fullfile(fileparts(mfilename('fullpath')), 'cwru_results.mat'));

% Extract arrays
conditions  = string(data.condition);
faults      = data.fault_size_mils;
loads       = data.load_hp;
sigma       = data.sigma;
sigma_norm  = data.sigma_norm;
r2          = data.r2;
n_freqs     = double(data.n_freqs);
rms_val     = data.rms;
kurt        = data.kurtosis;
crest       = data.crest_factor;
env_kurt    = data.envelope_kurtosis;
sk_mean     = data.spectral_kurtosis_mean;

% Create group labels: "Normal", "IR_7", "IR_14", etc.
N = length(conditions);
group_labels = strings(N, 1);
for i = 1:N
    if conditions(i) == "N"
        group_labels(i) = "Normal";
    else
        group_labels(i) = conditions(i) + "_" + num2str(faults(i));
    end
end

% Unique groups in desired order
group_order = ["Normal", "IR_7", "IR_14", "IR_21", ...
               "B_7", "B_14", "B_21", ...
               "OR_7", "OR_14", "OR_21"];
n_groups = length(group_order);

% Condition display labels
display_labels = {"Normal", "IR 7mil", "IR 14mil", "IR 21mil", ...
                  "B 7mil", "B 14mil", "B 21mil", ...
                  "OR 7mil", "OR 14mil", "OR 21mil"};

% Colors — Okabe-Ito colorblind-safe
c_normal = [0.00 0.45 0.70];  % blue
c_ir     = [0.80 0.40 0.00];  % orange
c_ball   = [0.00 0.62 0.45];  % teal
c_or     = [0.90 0.16 0.00];  % red

group_colors = [c_normal; c_ir; c_ir; c_ir; ...
                c_ball; c_ball; c_ball; ...
                c_or; c_or; c_or];

% Alpha for severity (lighter = smaller fault)
alpha_vals = [1.0, 0.5, 0.75, 1.0, 0.5, 0.75, 1.0, 0.5, 0.75, 1.0];

fig_dir = fullfile(fileparts(mfilename('fullpath')), 'figures');
if ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

% Helper: compute group stats
function [mu, sd, vals] = group_stat(data_vec, group_labels, group_name)
    mask = group_labels == group_name;
    vals = data_vec(mask);
    mu = mean(vals);
    sd = std(vals);
end

%% ════════════════════════════════════════════════════════════════
%  FIGURE 1: σ_norm bar chart with individual data points
%  ════════════════════════════════════════════════════════════════
fig1 = figure('Position', [100 100 900 450], 'Color', 'w');

for g = 1:n_groups
    [mu, sd, vals] = group_stat(sigma_norm, group_labels, group_order(g));

    % Bar
    col = group_colors(g,:) * alpha_vals(g) + (1 - alpha_vals(g)) * [1 1 1];
    bar(g, mu, 0.7, 'FaceColor', col, 'EdgeColor', group_colors(g,:), ...
        'LineWidth', 1.2); hold on;

    % Error bar
    errorbar(g, mu, sd, 'k', 'LineWidth', 1.2, 'CapSize', 6);

    % Individual points (jittered)
    jitter = 0.15 * (rand(size(vals)) - 0.5);
    scatter(g + jitter, vals, 18, group_colors(g,:), 'filled', ...
        'MarkerFaceAlpha', 0.5, 'MarkerEdgeColor', 'none');
end

% Reference line for Normal mean
[h_mu, ~, ~] = group_stat(sigma_norm, group_labels, "Normal");
yline(h_mu, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1, ...
    'Label', 'Normal baseline', 'FontSize', 16);

set(gca, 'XTick', 1:n_groups, 'XTickLabel', display_labels, ...
    'XTickLabelRotation', 35, 'FontSize', 18, 'FontName', 'Helvetica');
ylabel('\sigma_{norm} (normalized residual std)', 'FontSize', 25);
% title removed for journal
box on; grid on; set(gca, 'GridAlpha', 0.15);
ylim([0 max(sigma_norm)*1.15]);

% Add fault type brackets
annotation('textbox', [0.26 0.92 0.20 0.05], 'String', 'Inner Race', ...
    'FontSize', 10, 'FontWeight', 'bold', 'Color', c_ir, ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center');
annotation('textbox', [0.50 0.92 0.20 0.05], 'String', 'Ball', ...
    'FontSize', 10, 'FontWeight', 'bold', 'Color', c_ball, ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center');
annotation('textbox', [0.73 0.92 0.20 0.05], 'String', 'Outer Race', ...
    'FontSize', 10, 'FontWeight', 'bold', 'Color', c_or, ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center');

exportgraphics(fig1, fullfile(fig_dir, 'fig_sigma_norm_bars.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_sigma_norm_bars.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 2: Fisher Discriminant Ratio comparison (our features vs baselines)
%  ════════════════════════════════════════════════════════════════
fig2 = figure('Position', [100 100 700 400], 'Color', 'w');

% Compute FDR for each feature
features = {sigma_norm, sigma, rms_val, crest, kurt, env_kurt, sk_mean};
feat_names = {'\sigma_{norm}', '\sigma', 'RMS', 'Crest Factor', ...
              'Kurtosis', 'Env. Kurtosis', 'Spectral Kurt.'};
n_feat = length(features);

normal_mask = conditions == "N";
faulty_mask = conditions ~= "N";

fdrs = zeros(n_feat, 1);
for f = 1:n_feat
    h_vals = features{f}(normal_mask);
    f_vals = features{f}(faulty_mask);
    h_mu = mean(h_vals); h_sd = std(h_vals);
    f_mu = mean(f_vals); f_sd = std(f_vals);
    fdrs(f) = (h_mu - f_mu)^2 / (h_sd^2 + f_sd^2 + 1e-20);
end

% Sort by FDR
[fdrs_sorted, sort_idx] = sort(fdrs, 'descend');
feat_names_sorted = feat_names(sort_idx);

% Color: proposed (blue) vs baseline (gray)
bar_colors = zeros(n_feat, 3);
for f = 1:n_feat
    if sort_idx(f) <= 2  % sigma_norm or sigma
        bar_colors(f, :) = c_normal;  % blue = proposed
    else
        bar_colors(f, :) = [0.65 0.65 0.65];  % gray = baseline
    end
end

for f = 1:n_feat
    barh(n_feat - f + 1, fdrs_sorted(f), 0.6, 'FaceColor', bar_colors(f,:), ...
        'EdgeColor', 'k', 'LineWidth', 0.8); hold on;
    text(fdrs_sorted(f) + 0.05, n_feat - f + 1, sprintf('%.2f', fdrs_sorted(f)), ...
        'FontSize', 18, 'VerticalAlignment', 'middle');
end

set(gca, 'YTick', 1:n_feat, 'YTickLabel', flip(feat_names_sorted), ...
    'FontSize', 18, 'FontName', 'Helvetica');
xlabel('Fisher Discriminant Ratio (FDR)', 'FontSize', 25);
% title removed for journal
box on; grid on; set(gca, 'GridAlpha', 0.15);
xlim([0 max(fdrs)*1.25]);

% Legend
patch([0 0 0 0], [0 0 0 0], c_normal, 'EdgeColor', 'k');
patch([0 0 0 0], [0 0 0 0], [0.65 0.65 0.65], 'EdgeColor', 'k');
legend({'Proposed', 'Baseline'}, 'Location', 'southeast', 'FontSize', 18);

exportgraphics(fig2, fullfile(fig_dir, 'fig_fdr_comparison.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_fdr_comparison.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 3: σ vs Kurtosis scatter plot (2D feature space)
%  ════════════════════════════════════════════════════════════════
fig3 = figure('Position', [100 100 700 550], 'Color', 'w');

% Group by condition type
cond_types = ["N", "IR", "B", "OR"];
cond_colors = [c_normal; c_ir; c_ball; c_or];
cond_labels = {"Normal", "Inner Race", "Ball", "Outer Race"};
markers = {'o', 's', 'd', '^'};

for c = 1:4
    mask = conditions == cond_types(c);
    scatter(sigma(mask), kurt(mask), 120, cond_colors(c,:), markers{c}, ...
        'filled', 'MarkerFaceAlpha', 0.7, 'LineWidth', 1.2, ...
        'MarkerEdgeColor', cond_colors(c,:) * 0.6); hold on;
end

xlabel('\sigma (residual std)', 'FontSize', 25);
ylabel('Kurtosis', 'FontSize', 25);
% title removed for journal
legend(cond_labels, 'Location', 'northwest', 'FontSize', 18);
box on; grid on; set(gca, 'FontSize', 18, 'FontName', 'Helvetica', ...
    'GridAlpha', 0.15);

exportgraphics(fig3, fullfile(fig_dir, 'fig_sigma_vs_kurtosis.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_sigma_vs_kurtosis.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 4: σ severity progression (boxplot style)
%  ════════════════════════════════════════════════════════════════
fig4 = figure('Position', [100 100 800 450], 'Color', 'w');

% For each fault type, show Normal → 7mil → 14mil → 21mil
fault_types = ["IR", "B", "OR"];
fault_labels = {"Inner Race", "Ball", "Outer Race"};
ft_colors = [c_ir; c_ball; c_or];
severities = [0, 7, 14, 21];
sev_labels = {"Normal", "7 mil", "14 mil", "21 mil"};

for ft = 1:3
    subplot(1, 3, ft);

    for s = 1:4
        if s == 1
            mask = conditions == "N";
            col = c_normal;
        else
            mask = (conditions == fault_types(ft)) & (faults == severities(s));
            col = ft_colors(ft,:);
        end

        vals = sigma_norm(mask);

        % Box plot manually
        mu = mean(vals);
        sd = std(vals);
        q1 = prctile(vals, 25);
        q3 = prctile(vals, 75);
        med = median(vals);

        % Box
        rectangle('Position', [s-0.3, q1, 0.6, q3-q1], ...
            'FaceColor', [col 0.3], 'EdgeColor', col, 'LineWidth', 1.2);
        hold on;

        % Median line
        plot([s-0.3 s+0.3], [med med], 'Color', col, 'LineWidth', 2);

        % Whiskers
        plot([s s], [min(vals) q1], 'Color', col, 'LineWidth', 1);
        plot([s s], [q3 max(vals)], 'Color', col, 'LineWidth', 1);
        plot([s-0.15 s+0.15], [min(vals) min(vals)], 'Color', col, 'LineWidth', 1);
        plot([s-0.15 s+0.15], [max(vals) max(vals)], 'Color', col, 'LineWidth', 1);

        % Individual points
        jitter = 0.08 * randn(size(vals));
        scatter(s + jitter, vals, 35, col, 'filled', 'MarkerFaceAlpha', 0.4);
    end

    set(gca, 'XTick', 1:4, 'XTickLabel', sev_labels, ...
        'XTickLabelRotation', 25, 'FontSize', 9);
    ylabel('\sigma_{norm}', 'FontSize', 11);
    title(fault_labels{ft}, 'FontSize', 22, 'FontWeight', 'bold', ...
        'Color', ft_colors(ft,:));
    box on; grid on; set(gca, 'GridAlpha', 0.15, 'FontName', 'Helvetica');
    ylim([0.35 0.95]);
end

% sgtitle removed for journal

exportgraphics(fig4, fullfile(fig_dir, 'fig_severity_progression.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_severity_progression.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 5: σ_norm vs Load (robustness across operating conditions)
%  ════════════════════════════════════════════════════════════════
fig5 = figure('Position', [100 100 700 450], 'Color', 'w');

load_vals = [0, 1, 2, 3];
load_labels = {'0 HP', '1 HP', '2 HP', '3 HP'};

for c = 1:4
    mask_cond = conditions == cond_types(c);
    mu_per_load = zeros(4,1);
    sd_per_load = zeros(4,1);

    for L = 1:4
        mask = mask_cond & (loads == load_vals(L));
        vals = sigma_norm(mask);
        mu_per_load(L) = mean(vals);
        sd_per_load(L) = std(vals);
    end

    errorbar(load_vals, mu_per_load, sd_per_load, '-o', ...
        'Color', cond_colors(c,:), 'MarkerFaceColor', cond_colors(c,:), ...
        'LineWidth', 1.8, 'MarkerSize', 14, 'CapSize', 5); hold on;
end

xlabel('Motor Load (HP)', 'FontSize', 25);
ylabel('\sigma_{norm}', 'FontSize', 25);
% title removed for journal
legend(cond_labels, 'Location', 'best', 'FontSize', 18);
set(gca, 'XTick', 0:3, 'XTickLabel', load_labels, 'FontSize', 18, ...
    'FontName', 'Helvetica');
box on; grid on; set(gca, 'GridAlpha', 0.15);

exportgraphics(fig5, fullfile(fig_dir, 'fig_load_robustness.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_load_robustness.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 6: Multi-feature heatmap (correlation with fault presence)
%  ════════════════════════════════════════════════════════════════
fig6 = figure('Position', [100 100 800 400], 'Color', 'w');

% Compute mean feature values per group (normalized to [0,1])
feat_matrix = zeros(n_groups, 5);  % groups × features
feat_raw = {sigma_norm, sigma, kurt, env_kurt, rms_val};
feat_labels_hm = {'\sigma_{norm}', '\sigma', 'Kurtosis', 'Env. Kurt.', 'RMS'};

for g = 1:n_groups
    mask = group_labels == group_order(g);
    for f = 1:5
        feat_matrix(g, f) = mean(feat_raw{f}(mask));
    end
end

% Normalize each column to [0, 1]
for f = 1:5
    mn = min(feat_matrix(:, f));
    mx = max(feat_matrix(:, f));
    if mx > mn
        feat_matrix(:, f) = (feat_matrix(:, f) - mn) / (mx - mn);
    end
end

imagesc(feat_matrix');
colormap(flipud(bone));
cb = colorbar;
cb.Label.String = 'Normalized Value';
cb.Label.FontSize = 11;
caxis([0 1]);

set(gca, 'XTick', 1:n_groups, 'XTickLabel', display_labels, ...
    'XTickLabelRotation', 35, 'YTick', 1:5, 'YTickLabel', feat_labels_hm, ...
    'FontSize', 18, 'FontName', 'Helvetica');
% title removed for journal

% Add text values
for g = 1:n_groups
    for f = 1:5
        val = feat_matrix(g, f);
        if val > 0.5
            txt_col = 'w';
        else
            txt_col = 'k';
        end
        text(g, f, sprintf('%.2f', val), 'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', 'FontSize', 16, 'Color', txt_col);
    end
end

exportgraphics(fig6, fullfile(fig_dir, 'fig_feature_heatmap.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_feature_heatmap.pdf\n');

%% ════════════════════════════════════════════════════════════════
%  FIGURE 7: R² distribution showing good model fit
%  ════════════════════════════════════════════════════════════════
fig7 = figure('Position', [100 100 700 400], 'Color', 'w');

for g = 1:n_groups
    [mu, sd, vals] = group_stat(r2, group_labels, group_order(g));
    col = group_colors(g,:) * alpha_vals(g) + (1 - alpha_vals(g)) * [1 1 1];
    bar(g, mu, 0.7, 'FaceColor', col, 'EdgeColor', group_colors(g,:), ...
        'LineWidth', 1.2); hold on;
    errorbar(g, mu, sd, 'k', 'LineWidth', 1.2, 'CapSize', 6);
    jitter = 0.15 * (rand(size(vals)) - 0.5);
    scatter(g + jitter, vals, 18, group_colors(g,:), 'filled', ...
        'MarkerFaceAlpha', 0.5, 'MarkerEdgeColor', 'none');
end

set(gca, 'XTick', 1:n_groups, 'XTickLabel', display_labels, ...
    'XTickLabelRotation', 35, 'FontSize', 18, 'FontName', 'Helvetica');
ylabel('R^2 (harmonic model fit)', 'FontSize', 25);
% title removed for journal
box on; grid on; set(gca, 'GridAlpha', 0.15);
ylim([0 1]);

exportgraphics(fig7, fullfile(fig_dir, 'fig_r2_distribution.pdf'), ...
    'ContentType', 'vector', 'Resolution', 600);
fprintf('  Saved: fig_r2_distribution.pdf\n');

%%
fprintf('\n  All figures saved to: %s\n', fig_dir);
fprintf('  DONE.\n');
