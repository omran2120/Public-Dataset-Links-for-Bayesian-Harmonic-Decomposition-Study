"""
Regime-rule analysis for Priority 2 of the revision.

For each dataset, computes:
  - Mean R^2 (fit quality of the Bayesian harmonic decomposition)
  - FDR of sigma, sigma_norm, and RMS
  - The regime-selected variant per the R^2 > 0.5 rule (sigma_norm if R^2>0.5, else sigma)

Purpose: underwrite the claim that sigma-family + regime rule beats or matches
raw RMS on every dataset, with the honest numbers.
"""

import os
import sys
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
from functools import partial

print = partial(print, flush=True)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)


def fdr(h, f):
    h, f = np.asarray(h, float), np.asarray(f, float)
    s = np.var(h, ddof=0) + np.var(f, ddof=0)
    return float((np.mean(h) - np.mean(f))**2 / s) if s > 1e-20 else 0.0


def rms(x):
    return float(np.sqrt(np.mean(np.asarray(x, float) ** 2)))


all_results = {}

# --- CWRU ---
print("Loading CWRU...", end=" ")
cwru_dir = os.path.join(HERE, "..", "data", "cwru")
cwru_cat = {"97": "N", "98": "N", "99": "N", "100": "N",
            "105": "IR", "106": "IR", "107": "IR", "108": "IR",
            "169": "IR", "170": "IR", "171": "IR", "172": "IR",
            "209": "IR", "210": "IR", "211": "IR", "212": "IR",
            "118": "B", "119": "B", "120": "B", "121": "B",
            "185": "B", "186": "B", "187": "B", "188": "B",
            "222": "B", "223": "B", "224": "B", "225": "B",
            "130": "OR", "131": "OR", "132": "OR", "133": "OR",
            "197": "OR", "198": "OR", "199": "OR", "200": "OR",
            "234": "OR", "235": "OR", "236": "OR", "237": "OR"}
res = []
for fnum, cond in cwru_cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath):
        continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys:
        continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w * 12000:(w + 1) * 12000]
        if len(seg) < 12000:
            break
        f = bhd.analyze(seg, 12000)
        if f:
            f["condition"] = cond
            f["rms_raw"] = rms(seg - np.mean(seg))
            res.append(f)
all_results["CWRU"] = ("N", res)
print(f"{len(res)} windows")

# --- Paderborn ---
print("Loading Paderborn...", end=" ")
pb_dir = os.path.join(HERE, "..", "data", "paderborn")
pb_map = {"K001": "H", "K002": "H", "KA01": "OR", "KA04": "OR",
          "KI01": "IR", "KI04": "IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath):
        bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath):
        continue
    files = sorted([f for f in os.listdir(bpath)
                    if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0, 0]["Y"][0, 6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w * 16000:(w + 1) * 16000]
            if len(seg) < 16000:
                break
            f = bhd.analyze(seg, 16000)
            if f:
                f["condition"] = cond
                f["rms_raw"] = rms(seg - np.mean(seg))
                res.append(f)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)} windows")

# --- UOttawa ---
print("Loading UOttawa...", end=" ")
uo_dir = os.path.join(HERE, "..", "..", "data", "uottawa_mendeley")
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"):
            continue
        cc = fname[0]
        if cc not in "HOIBC":
            continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"):
                continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    seg = data[:20000]
                    f = bhd.analyze(seg, 20000)
                    if f:
                        f["condition"] = cond
                        f["rms_raw"] = rms(seg - np.mean(seg))
                        res.append(f)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)} windows")

# --- JNU ---
print("Loading JNU...", end=" ")
jnu_dir = os.path.join(HERE, "..", "data", "jnu")
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"):
            continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1:
                data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data) // 50000)):
                seg = data[w * 50000:(w + 1) * 50000]
                f = bhd.analyze(seg, 50000)
                if f:
                    f["condition"] = cond
                    f["rms_raw"] = rms(seg - np.mean(seg))
                    res.append(f)
        except Exception:
            pass
all_results["JNU"] = ("H", res)
print(f"{len(res)} windows")

# --- MFPT ---
print("Loading MFPT...", end=" ")
mfpt_dir = os.path.join(HERE, "..", "data", "mfpt")
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath):
            continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"):
                continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0, 0]["gs"].flatten()
                sr = int(d["bearing"][0, 0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                for w in range(min(3, len(gs) // sr)):
                    seg = gs[w * sr:(w + 1) * sr]
                    f = bhd.analyze(seg, sr)
                    if f:
                        f["condition"] = cond
                        f["rms_raw"] = rms(seg - np.mean(seg))
                        res.append(f)
            except Exception:
                pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)} windows")

# --- MCC5-THU (1000 RPM subset) ---
print("Loading MCC5 (1000)...", end=" ")
gear_dir = (r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD"
            r"\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU"
            r"\MCC5-THU gearbox fault diagnosis datasets")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        if "speed_circulation_10Nm-1000rpm" not in fname:
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            seg = sig[:20480]
            f = bhd.analyze(seg, 20480)
            if f:
                f["condition"] = cond
                f["rms_raw"] = rms(seg - np.mean(seg))
                res.append(f)
        except Exception:
            pass
all_results["MCC5 (1000)"] = ("H", res)
print(f"{len(res)} windows")

# --- MCC5-THU all speeds ---
print("Loading MCC5 (all)...", end=" ")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"):
            continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname),
                                 delimiter=",", skip_header=1)
            sig = data[:, 5]
            seg = sig[:20480]
            f = bhd.analyze(seg, 20480)
            if f:
                f["condition"] = cond
                f["rms_raw"] = rms(seg - np.mean(seg))
                res.append(f)
        except Exception:
            pass
all_results["MCC5 (all)"] = ("H", res)
print(f"{len(res)} windows")


# ------------------------------------------------------------------
#  Compute R^2 per dataset and FDR for sigma, sigma_norm, RMS
# ------------------------------------------------------------------
print("\n" + "=" * 100)
print("  REGIME RULE ANALYSIS (sigma vs sigma_norm vs RMS)")
print("=" * 100)
print(f"{'Dataset':<14}{'mean R^2':>10}{'rule picks':>12}"
      f"{'FDR sigma':>12}{'FDR s_norm':>12}{'FDR RMS':>10}"
      f"{'FDR rule':>10}  winner")

rows = []
for name, (hc, recs) in all_results.items():
    if not recs:
        continue
    h = [r for r in recs if r["condition"] == hc]
    f = [r for r in recs if r["condition"] != hc]
    if not h or not f:
        continue
    r2_all = np.array([r["r2"] for r in recs if r["r2"] is not None])
    r2_mean = float(np.mean(r2_all)) if r2_all.size else 0.0

    fdr_sigma = fdr([r["sigma_bayes"] for r in h],
                    [r["sigma_bayes"] for r in f])
    fdr_snorm = fdr([r["sigma_norm"] for r in h],
                    [r["sigma_norm"] for r in f])
    fdr_rms = fdr([r["rms_raw"] for r in h], [r["rms_raw"] for r in f])

    rule = "sigma_norm" if r2_mean > 0.5 else "sigma"
    fdr_rule = fdr_snorm if rule == "sigma_norm" else fdr_sigma

    winner = max([("sigma", fdr_sigma),
                  ("sigma_norm", fdr_snorm),
                  ("RMS", fdr_rms)],
                 key=lambda p: p[1])
    print(f"{name:<14}{r2_mean:>10.3f}{rule:>12}"
          f"{fdr_sigma:>12.3f}{fdr_snorm:>12.3f}{fdr_rms:>10.3f}"
          f"{fdr_rule:>10.3f}  {winner[0]} ({winner[1]:.2f})")
    rows.append({
        "dataset": name, "r2": r2_mean, "rule": rule,
        "fdr_sigma": fdr_sigma, "fdr_snorm": fdr_snorm,
        "fdr_rms": fdr_rms, "fdr_rule": fdr_rule,
    })

# Summary counts
wins_rule_beats_rms = sum(1 for r in rows if r["fdr_rule"] > r["fdr_rms"])
ties = sum(1 for r in rows
           if abs(r["fdr_rule"] - r["fdr_rms"]) < 0.10 * max(r["fdr_rms"], 1e-3))
print(f"\nRegime-selected variant beats RMS on {wins_rule_beats_rms}/{len(rows)} "
      f"conditions. Near-ties (within 10%): {ties}.")

# LaTeX rows for restructured Table 2
print("\n" + "=" * 100)
print("  Restructured Table 2 rows (regime-selected variant vs RMS)")
print("=" * 100)
for r in rows:
    variant = r"\sigma_{\mathrm{norm}}" if r["rule"] == "sigma_norm" else r"\sigma"
    better_rule = "\\textbf{%.2f}" % r["fdr_rule"] if r["fdr_rule"] >= r["fdr_rms"] \
        else "%.2f" % r["fdr_rule"]
    better_rms = "\\textbf{%.2f}" % r["fdr_rms"] if r["fdr_rms"] > r["fdr_rule"] \
        else "%.2f" % r["fdr_rms"]
    line = (f"  {r['dataset']} & {r['r2']:.2f} & ${variant}$ & "
            f"{better_rule} & {better_rms} \\\\")
    print(line)

print("\nDone.")
