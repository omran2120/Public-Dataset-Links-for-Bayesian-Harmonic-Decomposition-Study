"""
Run Bayesian Harmonic Diagnostic on ALL 7 datasets.
"""
import numpy as np
import scipy.io as sio
import scipy.signal as sig_proc
import os, sys
from functools import partial
print = partial(print, flush=True)

# Import from same folder
sys.path.insert(0, os.path.dirname(__file__))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic, fdr, auc

bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
all_results = {}

# === 1. CWRU ===
print("1. CWRU...", end=" ")
cwru_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\cwru"
cat = {"97":"N","98":"N","99":"N","100":"N","105":"IR","106":"IR","107":"IR","108":"IR",
       "169":"IR","170":"IR","171":"IR","172":"IR","209":"IR","210":"IR","211":"IR","212":"IR",
       "118":"B","119":"B","120":"B","121":"B","185":"B","186":"B","187":"B","188":"B",
       "222":"B","223":"B","224":"B","225":"B","130":"OR","131":"OR","132":"OR","133":"OR",
       "197":"OR","198":"OR","199":"OR","200":"OR","234":"OR","235":"OR","236":"OR","237":"OR"}
res = []
for fnum, cond in cat.items():
    fpath = os.path.join(cwru_dir, f"{fnum}.mat")
    if not os.path.exists(fpath): continue
    d = sio.loadmat(fpath)
    keys = [k for k in d.keys() if "DE_time" in k]
    if not keys: continue
    data = d[keys[0]].flatten()
    for w in range(4):
        seg = data[w*12000:(w+1)*12000]
        if len(seg) < 12000: break
        feats = bhd.analyze(seg, 12000)
        if feats: feats["condition"] = cond; res.append(feats)
all_results["CWRU"] = ("N", res)
print(f"{len(res)} measurements")

# === 2. PADERBORN ===
print("2. Paderborn...", end=" ")
pb_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\paderborn"
pb_map = {"K001":"H","K002":"H","KA01":"OR","KA04":"OR","KI01":"IR","KI04":"IR"}
res = []
for bearing, cond in pb_map.items():
    bpath = os.path.join(pb_dir, bearing, bearing)
    if not os.path.exists(bpath): bpath = os.path.join(pb_dir, bearing)
    if not os.path.exists(bpath): continue
    files = sorted([f for f in os.listdir(bpath) if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
    for fname in files:
        d = sio.loadmat(os.path.join(bpath, fname))
        key = [k for k in d.keys() if not k.startswith("_")][0]
        raw = d[key][0,0]["Y"][0,6]["Data"].flatten()
        data = sig_proc.decimate(raw, 4)
        for w in range(3):
            seg = data[w*16000:(w+1)*16000]
            if len(seg) < 16000: break
            feats = bhd.analyze(seg, 16000)
            if feats: feats["condition"] = cond; feats["bearing"] = bearing; res.append(feats)
all_results["Paderborn"] = ("H", res)
print(f"{len(res)} measurements")

# === 3. UOTTAWA ===
print("3. UOttawa...", end=" ")
uo_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\data\uottawa_mendeley"
res = []
if os.path.exists(uo_dir):
    for fname in sorted(os.listdir(uo_dir)):
        if not fname.endswith(".mat"): continue
        cc = fname[0]
        if cc not in "HOIBC": continue
        cond = "H" if cc == "H" else "F"
        d = sio.loadmat(os.path.join(uo_dir, fname))
        for key in d:
            if key.startswith("_"): continue
            arr = d[key]
            if hasattr(arr, "shape") and arr.size > 1000:
                data = sig_proc.decimate(arr.flatten(), 10)
                if len(data) >= 20000:
                    feats = bhd.analyze(data[:20000], 20000)
                    if feats: feats["condition"] = cond; feats["fault_type"] = cc; res.append(feats)
                break
all_results["UOttawa"] = ("H", res)
print(f"{len(res)} measurements")

# === 4. JNU ===
print("4. JNU...", end=" ")
jnu_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\jnu"
res = []
if os.path.exists(jnu_dir):
    for fname in sorted(os.listdir(jnu_dir)):
        if not fname.endswith(".csv"): continue
        try:
            data = np.loadtxt(os.path.join(jnu_dir, fname), delimiter=",")
            if data.ndim > 1: data = data[:, 0]
            cond = "H" if fname.startswith("n") else "F"
            for w in range(min(3, len(data)//50000)):
                seg = data[w*50000:(w+1)*50000]
                feats = bhd.analyze(seg, 50000)
                if feats: feats["condition"] = cond; res.append(feats)
        except: pass
all_results["JNU"] = ("H", res)
print(f"{len(res)} measurements")

# === 5. MFPT ===
print("5. MFPT...", end=" ")
mfpt_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data\mfpt"
res = []
if os.path.exists(mfpt_dir):
    for subdir in ["train_data", "test_data"]:
        spath = os.path.join(mfpt_dir, subdir)
        if not os.path.exists(spath): continue
        for fname in sorted(os.listdir(spath)):
            if not fname.endswith(".mat"): continue
            try:
                d = sio.loadmat(os.path.join(spath, fname))
                gs = d["bearing"][0,0]["gs"].flatten()
                sr = int(d["bearing"][0,0]["sr"].flatten()[0])
                cond = "H" if "baseline" in fname.lower() else "F"
                win_len = sr
                for w in range(min(3, len(gs)//win_len)):
                    seg = gs[w*win_len:(w+1)*win_len]
                    feats = bhd.analyze(seg, sr)
                    if feats: feats["condition"] = cond; res.append(feats)
            except: pass
all_results["MFPT"] = ("H", res)
print(f"{len(res)} measurements")

# === 6. MCC5-THU GEAR (constant speed 1000 RPM) ===
print("6. MCC5-THU gear (1000 RPM)...", end=" ")
gear_dir = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\CLASSIFICATION\Paper_Measurement\ExternalData\MCC5THU\MCC5-THU gearbox fault diagnosis datasets"
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"): continue
        if "speed_circulation_10Nm-1000rpm" not in fname: continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
            sig = data[:, 5]  # gearbox_vibration_x
            win_len = min(20480, len(sig))
            feats = bhd.analyze(sig[:win_len], 20480)
            if feats: feats["condition"] = cond; res.append(feats)
        except: pass
all_results["MCC5-1000"] = ("H", res)
print(f"{len(res)} measurements")

# === 7. MCC5-THU GEAR (all speeds pooled) ===
print("7. MCC5-THU gear (all speeds)...", end=" ")
res = []
if os.path.exists(gear_dir):
    for fname in sorted(os.listdir(gear_dir)):
        if not fname.endswith(".csv"): continue
        if "speed_circulation" not in fname: continue
        cond = "H" if fname.startswith("health") else "F"
        try:
            data = np.genfromtxt(os.path.join(gear_dir, fname), delimiter=",", skip_header=1)
            sig = data[:, 5]
            win_len = min(20480, len(sig))
            feats = bhd.analyze(sig[:win_len], 20480)
            if feats: feats["condition"] = cond; res.append(feats)
        except: pass
all_results["MCC5-all"] = ("H", res)
print(f"{len(res)} measurements")

# ============================================================
# RESULTS
# ============================================================
print("\n" + "="*100)
print("  COMPLETE RESULTS: Bayesian σ vs Frequentist σ vs Kurtosis(resid)")
print("="*100)

print(f"\n  {'Dataset':<14s} | {'σ_bayes FDR':>12s} {'σ_freq FDR':>11s} {'ResK FDR':>10s} | {'σ_bayes AUC':>12s} {'σ_freq AUC':>11s} {'ResK AUC':>10s} | {'R2':>5s} | {'N':>4s}")
print(f"  {'-'*14}-+-{'-'*12}-{'-'*11}-{'-'*10}-+-{'-'*12}-{'-'*11}-{'-'*10}-+-{'-'*5}-+-{'-'*4}")

for name in ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5-1000", "MCC5-all"]:
    if name not in all_results: continue
    hc, results = all_results[name]
    if not results: continue
    h = [r for r in results if r["condition"] == hc]
    f = [r for r in results if r["condition"] != hc]
    if not h or not f: continue
    sb_f = fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
    sb_a = auc([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
    sf_f = fdr([r["sigma"] for r in h], [r["sigma"] for r in f])
    sf_a = auc([r["sigma"] for r in h], [r["sigma"] for r in f])
    kf_f = fdr([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
    kf_a = auc([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
    r2m = np.mean([r["r2"] for r in results])
    n = len(results)
    print(f"  {name:<14s} | {sb_f:>12.3f} {sf_f:>11.3f} {kf_f:>10.3f} | {sb_a:>12.3f} {sf_a:>11.3f} {kf_a:>10.3f} | {r2m:>5.3f} | {n:>4d}")

# UNCERTAINTY
print(f"\n  UNCERTAINTY QUANTIFICATION (95% Bayesian CI for σ):")
print(f"  {'Dataset':<14s} | {'Healthy σ':>10s} {'[95% CI]':>25s} | {'Faulty σ':>10s} {'[95% CI]':>25s} | Overlap?")
print(f"  {'-'*14}-+-{'-'*10}-{'-'*25}-+-{'-'*10}-{'-'*25}-+---------")

for name in ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5-1000", "MCC5-all"]:
    if name not in all_results: continue
    hc, results = all_results[name]
    if not results: continue
    h = [r for r in results if r["condition"] == hc]
    f = [r for r in results if r["condition"] != hc]
    if not h or not f: continue
    hm = np.mean([r["sigma_bayes"] for r in h])
    hl = np.mean([r["sigma_bayes_ci_low"] for r in h])
    hh = np.mean([r["sigma_bayes_ci_high"] for r in h])
    fm = np.mean([r["sigma_bayes"] for r in f])
    fl = np.mean([r["sigma_bayes_ci_low"] for r in f])
    fh = np.mean([r["sigma_bayes_ci_high"] for r in f])
    overlap = "NO" if hh < fl or fh < hl else "YES"
    print(f"  {name:<14s} | {hm:>10.6f} [{hl:.6f}, {hh:.6f}] | {fm:>10.6f} [{fl:.6f}, {fh:.6f}] | {overlap}")

# PADERBORN PER BEARING
print(f"\n  PADERBORN PER BEARING:")
hc, pb = all_results["Paderborn"]
for bearing in ["K001", "K002", "KA01", "KA04", "KI01", "KI04"]:
    sub = [r for r in pb if r.get("bearing") == bearing]
    if sub:
        sb = np.mean([r["sigma_bayes"] for r in sub])
        ci_l = np.mean([r["sigma_bayes_ci_low"] for r in sub])
        ci_h = np.mean([r["sigma_bayes_ci_high"] for r in sub])
        rk = np.mean([r["resid_kurtosis"] for r in sub])
        print(f"    {bearing}: σ_bayes={sb:.4f} [{ci_l:.4f}, {ci_h:.4f}]  resid_kurt={rk:.2f}")

# SCORE CARD
print(f"\n  SCORE CARD: σ_bayes vs ResKurt (by FDR)")
sigma_wins = 0
kurt_wins = 0
for name in ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5-1000", "MCC5-all"]:
    if name not in all_results: continue
    hc, results = all_results[name]
    if not results: continue
    h = [r for r in results if r["condition"] == hc]
    f = [r for r in results if r["condition"] != hc]
    if not h or not f: continue
    sb_f = fdr([r["sigma_bayes"] for r in h], [r["sigma_bayes"] for r in f])
    kf_f = fdr([r["resid_kurtosis"] for r in h], [r["resid_kurtosis"] for r in f])
    winner = "σ_bayes" if sb_f > kf_f else "ResKurt"
    if sb_f > kf_f: sigma_wins += 1
    else: kurt_wins += 1
    print(f"    {name:<14s}: σ_bayes FDR={sb_f:.3f}  ResKurt FDR={kf_f:.3f}  → {winner}")
print(f"\n    σ_bayes wins: {sigma_wins}/7")
print(f"    ResKurt wins: {kurt_wins}/7")

# TIMING
print(f"\n  TIMING:")
for name in ["CWRU", "Paderborn", "UOttawa", "JNU", "MFPT", "MCC5-1000"]:
    if name not in all_results: continue
    hc, results = all_results[name]
    if results:
        avg_t = np.mean([r.get("elapsed", 0) for r in results])
        print(f"    {name}: {avg_t:.3f}s per window ({len(results)} windows)")

print("\nDone!")
