"""
Task-3 reviewer analyses for the RESS (BH) paper:
  (A) pseudo-replication: window-level vs file/bearing-level FDR & AUC
  (B) independent threshold validation: leave-one-load-out (CWRU),
      leave-one-bearing-out (Paderborn)
  (C) N_f sensitivity (number of retained FFT peaks)
  (D) regime-rule classification accuracy on all windows

Re-runs the Bayesian engine on CWRU + Paderborn (data present locally),
caches per-window features to task3_features.json, prints a summary, and
writes task3_results.json.
"""
import numpy as np, scipy.io as sio, scipy.signal as sig_proc
import os, sys, json
from functools import partial
print = partial(print, flush=True)

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "bayesian_approach"))
from bayesian_harmonic_diagnostic import BayesianHarmonicDiagnostic, fdr, auc

DATA = r"C:\Users\omran\OneDrive - University of Manitoba\Desktop\PhD\Governing Equations\Codes\final_codes\paper\data"

def feats_for(seg, fs, bhd):
    f = bhd.analyze(seg, fs)
    if not f: return None
    f["sigma_norm_b"] = f["sigma_bayes"] / f["rms"] if f["rms"] > 1e-20 else 0.0
    return f

# ---------------------------------------------------------------- load data
def load_cwru(bhd):
    # groups of 4 files = loads 0,1,2,3
    groups = [
        ("N", ["97","98","99","100"]),
        ("IR",["105","106","107","108"]), ("IR",["169","170","171","172"]), ("IR",["209","210","211","212"]),
        ("B", ["118","119","120","121"]), ("B", ["185","186","187","188"]), ("B", ["222","223","224","225"]),
        ("OR",["130","131","132","133"]), ("OR",["197","198","199","200"]), ("OR",["234","235","236","237"]),
    ]
    rows = []
    for cond, files in groups:
        for load, fnum in enumerate(files):
            fp = os.path.join(DATA, "cwru", f"{fnum}.mat")
            if not os.path.exists(fp): continue
            d = sio.loadmat(fp)
            keys = [k for k in d if "DE_time" in k]
            if not keys: continue
            data = d[keys[0]].flatten()
            for w in range(4):
                seg = data[w*12000:(w+1)*12000]
                if len(seg) < 12000: break
                ft = feats_for(seg, 12000, bhd)
                if ft:
                    rows.append(dict(dataset="CWRU", cond=cond, label=0 if cond=="N" else 1,
                                     file=fnum, load=load, win=w,
                                     sigma=ft["sigma_bayes"], sigma_norm=ft["sigma_norm_b"],
                                     r2=ft["r2"], rms=ft["rms"], kurt=ft["resid_kurtosis"]))
    return rows

def load_paderborn(bhd):
    pb_map = {"K001":"H","K002":"H","KA01":"OR","KA04":"OR","KI01":"IR","KI04":"IR"}
    rows = []
    for bearing, cond in pb_map.items():
        bpath = os.path.join(DATA, "paderborn", bearing, bearing)
        if not os.path.exists(bpath): bpath = os.path.join(DATA, "paderborn", bearing)
        if not os.path.exists(bpath): continue
        files = sorted([f for f in os.listdir(bpath)
                        if f.startswith("N15_M07_F10") and f.endswith(".mat")])[:5]
        for fi, fname in enumerate(files):
            d = sio.loadmat(os.path.join(bpath, fname))
            key = [k for k in d if not k.startswith("_")][0]
            raw = d[key][0,0]["Y"][0,6]["Data"].flatten()
            data = sig_proc.decimate(raw, 4)
            for w in range(3):
                seg = data[w*16000:(w+1)*16000]
                if len(seg) < 16000: break
                ft = feats_for(seg, 16000, bhd)
                if ft:
                    rows.append(dict(dataset="Paderborn", cond=cond, label=0 if cond=="H" else 1,
                                     file=fname, bearing=bearing, win=w,
                                     sigma=ft["sigma_bayes"], sigma_norm=ft["sigma_norm_b"],
                                     r2=ft["r2"], rms=ft["rms"], kurt=ft["resid_kurtosis"]))
    return rows

# ---------------------------------------------------------------- metrics
def group_mean(rows, keyfn, scorekey):
    """Aggregate a score per group (file/bearing). Returns (h_scores, f_scores)."""
    groups = {}
    for r in rows:
        k = keyfn(r)
        groups.setdefault(k, []).append(r)
    h, f = [], []
    for k, rs in groups.items():
        m = float(np.mean([r[scorekey] for r in rs]))
        (h if rs[0]["label"]==0 else f).append(m)
    return h, f

def bal_acc(h_scores, f_scores, thr):
    h, f = np.array(h_scores), np.array(f_scores)
    tnr = np.mean(h <= thr) if len(h) else 0.0   # healthy correctly NOT flagged
    tpr = np.mean(f >  thr) if len(f) else 0.0    # faulty correctly flagged
    return 0.5*(tpr+tnr), tpr, 1-tnr  # bal_acc, detection, false_alarm

# ---------------------------------------------------------------- run
def main():
    bhd = BayesianHarmonicDiagnostic(max_freqs=80, prior_precision=1.0)
    print("Loading CWRU ..."); cwru = load_cwru(bhd); print(f"  {len(cwru)} windows")
    print("Loading Paderborn ..."); pb = load_paderborn(bhd); print(f"  {len(pb)} windows")
    json.dump({"CWRU":cwru,"Paderborn":pb}, open("task3_features.json","w"))

    out = {}

    # (A) pseudo-replication: window vs file/bearing level
    print("\n=== (A) Window-level vs file/bearing-level (regime-selected score) ===")
    # CWRU -> sigma_norm ; Paderborn -> sigma
    A = {}
    for name, rows, score in [("CWRU", cwru, "sigma_norm"), ("Paderborn", pb, "sigma")]:
        h_w = [r[score] for r in rows if r["label"]==0]; f_w = [r[score] for r in rows if r["label"]==1]
        fdr_w, auc_w = fdr(h_w,f_w), auc(h_w,f_w)
        keyfn = (lambda r: r["file"])  # file-level (CWRU 40 files, Paderborn 30 files)
        h_g, f_g = group_mean(rows, keyfn, score)
        fdr_g, auc_g = fdr(h_g,f_g), auc(h_g,f_g)
        A[name] = dict(score=score, n_win=len(rows), fdr_window=fdr_w, auc_window=auc_w,
                       n_files=len(h_g)+len(f_g), fdr_file=fdr_g, auc_file=auc_g)
        print(f"  {name:10s} [{score}]  window: FDR={fdr_w:.2f} AUC={auc_w:.3f} (n={len(rows)})"
              f"   file/bearing: FDR={fdr_g:.2f} AUC={auc_g:.3f} (n={len(h_g)+len(f_g)})")
    out["pseudo_replication"] = A

    # (B1) leave-one-load-out on CWRU (threshold from healthy of other loads)
    print("\n=== (B1) CWRU leave-one-load-out (sigma_norm, tau=97.5% healthy quantile) ===")
    loads = sorted(set(r["load"] for r in cwru))
    accs, dets, fas = [], [], []
    for L in loads:
        train_h = [r["sigma_norm"] for r in cwru if r["label"]==0 and r["load"]!=L]
        tau = float(np.quantile(train_h, 0.975))
        test = [r for r in cwru if r["load"]==L]
        h = [r["sigma_norm"] for r in test if r["label"]==0]
        f = [r["sigma_norm"] for r in test if r["label"]==1]
        ba, det, fa = bal_acc(h, f, tau)
        accs.append(ba); dets.append(det); fas.append(fa)
        print(f"  hold-out load {L}: tau={tau:.3f}  bal_acc={ba:.3f}  detection={det:.3f}  false_alarm={fa:.3f}")
    out["cwru_loocv_load"] = dict(mean_bal_acc=float(np.mean(accs)), mean_detection=float(np.mean(dets)),
                                  mean_false_alarm=float(np.mean(fas)), per_fold_bal_acc=accs)
    print(f"  MEAN: bal_acc={np.mean(accs):.3f}  detection={np.mean(dets):.3f}  false_alarm={np.mean(fas):.3f}")

    # (B2) leave-one-bearing-out on Paderborn (sigma; threshold from healthy windows)
    print("\n=== (B2) Paderborn leave-one-bearing-out (sigma, tau=97.5% healthy quantile) ===")
    res_b = {}
    healthy_bearings = ["K001","K002"]
    faulty_bearings = ["KA01","KA04","KI01","KI04"]
    # detection on each held-out faulty bearing, threshold from BOTH healthy bearings
    tau_all_h = float(np.quantile([r["sigma"] for r in pb if r["label"]==0], 0.975))
    for b in faulty_bearings:
        sc = [r["sigma"] for r in pb if r.get("bearing")==b]
        det = float(np.mean(np.array(sc) > tau_all_h))
        res_b[b] = dict(role="faulty", detection=det, tau=tau_all_h)
        print(f"  faulty {b}: detection={det:.3f} (tau={tau_all_h:.3f} from healthy windows)")
    # false alarm on each held-out healthy bearing, threshold from the OTHER healthy bearing
    for b in healthy_bearings:
        other = [hb for hb in healthy_bearings if hb!=b]
        train_h = [r["sigma"] for r in pb if r.get("bearing") in other]
        tau = float(np.quantile(train_h, 0.975))
        sc = [r["sigma"] for r in pb if r.get("bearing")==b]
        fa = float(np.mean(np.array(sc) > tau))
        res_b[b] = dict(role="healthy_heldout", false_alarm=fa, tau=tau)
        print(f"  healthy {b} (tau from {other[0]}): false_alarm={fa:.3f} (tau={tau:.3f})")
    out["paderborn_loocv_bearing"] = res_b

    # (C) N_f sensitivity on CWRU (sigma_norm FDR vs number of retained peaks)
    print("\n=== (C) N_f sensitivity (CWRU, sigma_norm FDR) ===")
    nf_curve = {}
    for nf in [20, 40, 60, 80, 120]:
        bhd2 = BayesianHarmonicDiagnostic(max_freqs=nf, prior_precision=1.0)
        hh, ff = [], []
        for r in cwru:  # reuse the same windows? need raw signal -> re-run quick on CWRU only
            pass
        # re-run CWRU windows for this nf (CWRU is small/fast)
        rows = load_cwru(bhd2)
        h = [x["sigma_norm"] for x in rows if x["label"]==0]
        f = [x["sigma_norm"] for x in rows if x["label"]==1]
        nf_curve[nf] = dict(fdr=fdr(h,f), auc=auc(h,f))
        print(f"  N_f={nf:4d}: sigma_norm FDR={fdr(h,f):.3f}  AUC={auc(h,f):.3f}")
    out["nf_sensitivity_cwru"] = nf_curve

    # (D) regime-rule classification accuracy on all windows
    print("\n=== (D) Regime-rule classification (per-dataset, tau=97.5% healthy quantile) ===")
    D = {}
    for name, rows in [("CWRU", cwru), ("Paderborn", pb)]:
        meanR2 = float(np.mean([r["r2"] for r in rows]))
        score = "sigma_norm" if meanR2 > 0.5 else "sigma"
        h = [r[score] for r in rows if r["label"]==0]; f = [r[score] for r in rows if r["label"]==1]
        tau = float(np.quantile(h, 0.975))
        ba, det, fa = bal_acc(h, f, tau)
        D[name] = dict(meanR2=meanR2, variant=score, tau=tau, bal_acc=ba, detection=det, false_alarm=fa)
        print(f"  {name:10s} R2={meanR2:.2f} -> {score:11s}  bal_acc={ba:.3f}  det={det:.3f}  FA={fa:.3f}")
    out["regime_rule_accuracy"] = D

    json.dump(out, open("task3_results.json","w"), indent=2)
    print("\nSaved task3_results.json and task3_features.json")

if __name__ == "__main__":
    main()
